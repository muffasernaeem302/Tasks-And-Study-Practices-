module com.uptime.dashboard {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swing;
    requires javafx.graphics;
    requires javafx.base;

    requires spring.context;
    requires spring.boot;
    requires spring.boot.autoconfigure;
    requires spring.data.jpa;
    requires spring.beans;

    requires jakarta.persistence;
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.datatype.jsr310;
    requires java.net.http;
    requires java.desktop;
    requires org.slf4j;
    requires static lombok;

    opens com.uptime.dashboard to spring.core, spring.beans, spring.context;
    opens com.uptime.dashboard.model to spring.core, org.hibernate.orm.core, jakarta.persistence;
    opens com.uptime.dashboard.repository to spring.core, spring.data.jpa;
    opens com.uptime.dashboard.service to spring.core, spring.beans, spring.context;
    opens com.uptime.dashboard.controller to spring.core;
    opens com.uptime.dashboard.config to spring.core, spring.beans, spring.context;
    opens com.uptime.dashboard.ui.views to javafx.fxml, spring.core, spring.beans;
    opens com.uptime.dashboard.ui.components to javafx.fxml;
    opens com.uptime.dashboard.util to spring.core;

    exports com.uptime.dashboard;
    exports com.uptime.dashboard.model;
    exports com.uptime.dashboard.service;
    exports com.uptime.dashboard.ui.views;
    exports com.uptime.dashboard.ui.components;
    exports com.uptime.dashboard.util;
}
