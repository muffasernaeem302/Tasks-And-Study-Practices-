package com.uptime.dashboard.service;

import com.uptime.dashboard.model.AppSettings;
import com.uptime.dashboard.model.Incident;
import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.repository.AppSettingsRepository;
import com.uptime.dashboard.repository.IncidentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class IncidentService {

    private final IncidentRepository incidentRepository;
    private final AppSettingsRepository settingsRepo;
    private final WebhookService webhookService;
    private final NotificationService notificationService;

    @Transactional
    public Incident openIncident(MonitoredEndpoint endpoint, String description) {
        // Check if there is already an active incident
        Optional<Incident> existing = incidentRepository.findActiveIncidentForEndpoint(endpoint);
        if (existing.isPresent()) {
            Incident activeIncident = existing.get();
            // Check re-notification throttle
            int reNotifyMinutes = getReNotificationMinutes();
            LocalDateTime lastAlert = activeIncident.getLastAlertSentAt();
            if (lastAlert == null || ChronoUnit.MINUTES.between(lastAlert, LocalDateTime.now()) >= reNotifyMinutes) {
                activeIncident.setAlertCount(activeIncident.getAlertCount() + 1);
                activeIncident.setLastAlertSentAt(LocalDateTime.now());
                incidentRepository.save(activeIncident);
                webhookService.sendDownAlert(endpoint, activeIncident);
                notificationService.sendDesktopAlert("Still DOWN: " + endpoint.getName(), endpoint.getUrl());
            }
            return activeIncident;
        }

        // Open a new incident
        Incident incident = Incident.builder()
                .endpoint(endpoint)
                .status(Incident.IncidentStatus.OPEN)
                .title("Outage: " + endpoint.getName())
                .description(description)
                .openedAt(LocalDateTime.now())
                .lastAlertSentAt(LocalDateTime.now())
                .alertCount(1)
                .build();

        incident = incidentRepository.save(incident);
        log.warn("Incident opened for endpoint: {} ({})", endpoint.getName(), endpoint.getUrl());

        webhookService.sendDownAlert(endpoint, incident);
        notificationService.sendDesktopAlert("DOWN: " + endpoint.getName(), endpoint.getUrl());

        return incident;
    }

    @Transactional
    public void resolveIncident(MonitoredEndpoint endpoint) {
        Optional<Incident> activeOpt = incidentRepository.findActiveIncidentForEndpoint(endpoint);
        if (activeOpt.isEmpty()) return;

        Incident incident = activeOpt.get();
        incident.setStatus(Incident.IncidentStatus.RESOLVED);
        incident.setResolvedAt(LocalDateTime.now());
        long duration = ChronoUnit.MINUTES.between(incident.getOpenedAt(), LocalDateTime.now());
        incident.setDurationMinutes(duration);
        incidentRepository.save(incident);

        log.info("Incident resolved for endpoint: {} after {} minutes", endpoint.getName(), duration);
        webhookService.sendRecoveryAlert(endpoint);
        notificationService.sendDesktopAlert("RECOVERED: " + endpoint.getName(),
                "Back online after " + duration + " minutes");
    }

    @Transactional
    public void acknowledgeIncident(Long incidentId, String acknowledgedBy) {
        incidentRepository.findById(incidentId).ifPresent(incident -> {
            incident.setStatus(Incident.IncidentStatus.ACKNOWLEDGED);
            incident.setAcknowledgedAt(LocalDateTime.now());
            incident.setAcknowledgedBy(acknowledgedBy != null ? acknowledgedBy : "Dashboard User");
            incidentRepository.save(incident);
            log.info("Incident {} acknowledged by {}", incidentId, acknowledgedBy);
        });
    }

    public List<Incident> getActiveIncidents() {
        return incidentRepository.findAllActiveIncidents();
    }

    public List<Incident> getAllIncidents() {
        return incidentRepository.findAll(
                org.springframework.data.domain.Sort.by(
                        org.springframework.data.domain.Sort.Direction.DESC, "openedAt"));
    }

    public long countOpenIncidents() {
        return incidentRepository.countOpenIncidents();
    }

    private int getReNotificationMinutes() {
        return settingsRepo.findById(AppSettings.RE_NOTIFICATION_MINUTES)
                .map(s -> Integer.parseInt(s.getValue()))
                .orElse(60);
    }
}
