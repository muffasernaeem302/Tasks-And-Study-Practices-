package com.uptime.dashboard.repository;

import com.uptime.dashboard.model.HealthCheckLog;
import com.uptime.dashboard.model.MonitoredEndpoint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface HealthCheckLogRepository extends JpaRepository<HealthCheckLog, Long> {

    List<HealthCheckLog> findByEndpointOrderByCheckedAtDesc(MonitoredEndpoint endpoint);

    List<HealthCheckLog> findTop100ByEndpointOrderByCheckedAtDesc(MonitoredEndpoint endpoint);

    @Query("SELECT h FROM HealthCheckLog h WHERE h.endpoint = :endpoint AND h.checkedAt >= :since ORDER BY h.checkedAt ASC")
    List<HealthCheckLog> findByEndpointAndCheckedAtAfter(
            @Param("endpoint") MonitoredEndpoint endpoint,
            @Param("since") LocalDateTime since);

    @Query("SELECT COUNT(h) FROM HealthCheckLog h WHERE h.endpoint = :endpoint AND h.checkedAt >= :since AND h.success = true")
    long countSuccessfulChecks(@Param("endpoint") MonitoredEndpoint endpoint, @Param("since") LocalDateTime since);

    @Query("SELECT COUNT(h) FROM HealthCheckLog h WHERE h.endpoint = :endpoint AND h.checkedAt >= :since")
    long countTotalChecks(@Param("endpoint") MonitoredEndpoint endpoint, @Param("since") LocalDateTime since);

    @Query(value = """
        SELECT PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY h.latency_ms)
        FROM health_check_logs h
        WHERE h.endpoint_id = :endpointId AND h.checked_at >= :since AND h.latency_ms IS NOT NULL
        """, nativeQuery = true)
    Double calculateP95Latency(@Param("endpointId") Long endpointId, @Param("since") LocalDateTime since);

    @Query(value = """
        SELECT PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY h.latency_ms)
        FROM health_check_logs h
        WHERE h.endpoint_id = :endpointId AND h.checked_at >= :since AND h.latency_ms IS NOT NULL
        """, nativeQuery = true)
    Double calculateP99Latency(@Param("endpointId") Long endpointId, @Param("since") LocalDateTime since);

    void deleteByCheckedAtBefore(LocalDateTime cutoff);
}
