package com.uptime.dashboard.ui.components;

import com.uptime.dashboard.model.MonitoredEndpoint;
import javafx.scene.control.Label;

public class StatusBadge extends Label {

    public StatusBadge(MonitoredEndpoint.EndpointStatus status) {
        super(labelFor(status));
        getStyleClass().addAll("status-badge", styleFor(status));
    }

    public void update(MonitoredEndpoint.EndpointStatus status) {
        setText(labelFor(status));
        getStyleClass().removeAll("up", "down", "warn", "unknown");
        getStyleClass().add(styleFor(status));
    }

    private static String labelFor(MonitoredEndpoint.EndpointStatus status) {
        return switch (status) {
            case UP      -> "● UP";
            case DOWN    -> "● DOWN";
            case DEGRADED -> "● DEGRADED";
            case UNKNOWN -> "● UNKNOWN";
        };
    }

    private static String styleFor(MonitoredEndpoint.EndpointStatus status) {
        return switch (status) {
            case UP      -> "up";
            case DOWN    -> "down";
            case DEGRADED -> "warn";
            case UNKNOWN -> "unknown";
        };
    }
}
