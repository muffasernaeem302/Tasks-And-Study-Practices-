package com.uptime.dashboard.repository;

import com.uptime.dashboard.model.Incident;
import com.uptime.dashboard.model.MonitoredEndpoint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, Long> {

    List<Incident> findByStatusInOrderByOpenedAtDesc(List<Incident.IncidentStatus> statuses);

    Optional<Incident> findFirstByEndpointAndStatusIn(
            MonitoredEndpoint endpoint,
            List<Incident.IncidentStatus> statuses);

    List<Incident> findByEndpointOrderByOpenedAtDesc(MonitoredEndpoint endpoint);

    @Query("SELECT i FROM Incident i WHERE i.status IN ('OPEN', 'ACKNOWLEDGED') ORDER BY i.openedAt DESC")
    List<Incident> findAllActiveIncidents();

    @Query("SELECT COUNT(i) FROM Incident i WHERE i.status = 'OPEN'")
    long countOpenIncidents();

    @Query("SELECT i FROM Incident i ORDER BY i.openedAt DESC")
    List<Incident> findRecentIncidents(org.springframework.data.domain.Pageable pageable);

    @Query("SELECT i FROM Incident i WHERE i.endpoint = :endpoint AND i.status NOT IN ('RESOLVED') ORDER BY i.openedAt DESC")
    Optional<Incident> findActiveIncidentForEndpoint(@Param("endpoint") MonitoredEndpoint endpoint);
}
