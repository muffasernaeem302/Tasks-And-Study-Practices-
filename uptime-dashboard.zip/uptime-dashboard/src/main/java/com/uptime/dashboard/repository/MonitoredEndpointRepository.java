package com.uptime.dashboard.repository;

import com.uptime.dashboard.model.MonitoredEndpoint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MonitoredEndpointRepository extends JpaRepository<MonitoredEndpoint, Long> {

    List<MonitoredEndpoint> findByEnabledTrue();

    List<MonitoredEndpoint> findByCurrentStatus(MonitoredEndpoint.EndpointStatus status);

    @Query("SELECT COUNT(e) FROM MonitoredEndpoint e WHERE e.enabled = true AND e.currentStatus = 'DOWN'")
    long countActiveOutages();

    @Query("SELECT AVG(e.lastLatencyMs) FROM MonitoredEndpoint e WHERE e.enabled = true AND e.lastLatencyMs IS NOT NULL")
    Double averageLatency();
}
