package com.uptime.dashboard.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

@Entity
@Table(name = "health_check_logs", indexes = {
    @Index(name = "idx_log_endpoint_time", columnList = "endpoint_id, checked_at"),
    @Index(name = "idx_log_checked_at", columnList = "checked_at")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HealthCheckLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "endpoint_id", nullable = false)
    private MonitoredEndpoint endpoint;

    @Column(name = "checked_at", nullable = false)
    @Builder.Default
    private LocalDateTime checkedAt = LocalDateTime.now();

    @Column(name = "http_status_code")
    private Integer httpStatusCode;

    @Column(name = "latency_ms")
    private Long latencyMs;

    @Column(name = "success")
    private boolean success;

    @Column(name = "error_message", length = 1000)
    private String errorMessage;

    @Column(name = "ssl_expiry_days")
    private Integer sslExpiryDays;

    @Enumerated(EnumType.STRING)
    @Column(name = "status_at_check")
    private MonitoredEndpoint.EndpointStatus statusAtCheck;
}
