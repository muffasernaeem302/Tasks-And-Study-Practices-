package com.uptime.dashboard.ui.components;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class MetricCard extends VBox {

    private final Label valueLabel;
    private final Label titleLabel;

    public MetricCard(String title, String initialValue, String styleClass) {
        super(4);
        setAlignment(Pos.CENTER_LEFT);
        getStyleClass().add("metric-card");

        valueLabel = new Label(initialValue);
        valueLabel.getStyleClass().addAll("metric-card-value", styleClass);

        titleLabel = new Label(title.toUpperCase());
        titleLabel.getStyleClass().add("metric-card-label");

        getChildren().addAll(valueLabel, titleLabel);
    }

    public void setValue(String value) {
        valueLabel.setText(value);
    }

    public void setStyleVariant(String... styleClasses) {
        valueLabel.getStyleClass().removeAll("up", "down", "warn", "info");
        valueLabel.getStyleClass().addAll(styleClasses);
    }
}
