package com.uptime.dashboard;

import com.uptime.dashboard.service.MonitoringService;
import com.uptime.dashboard.service.NotificationService;
import com.uptime.dashboard.ui.views.MainDashboardView;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
@Slf4j
public class UptimeDashboardApp extends Application {

    private ConfigurableApplicationContext springContext;
    private MonitoringService monitoringService;
    private NotificationService notificationService;

    public static void main(String[] args) {
        // Launch JavaFX (which calls init() -> start())
        Application.launch(UptimeDashboardApp.class, args);
    }

    @Override
    public void init() {
        // Bootstrap Spring on a background thread before JavaFX starts
        springContext = SpringApplication.run(UptimeDashboardApp.class);
        monitoringService = springContext.getBean(MonitoringService.class);
        notificationService = springContext.getBean(NotificationService.class);
        notificationService.initialize();
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            MainDashboardView dashboardView = springContext.getBean(MainDashboardView.class);
            Scene scene = dashboardView.buildScene();

            primaryStage.setTitle("Uptime, SSL & Incident Management Dashboard");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(1200);
            primaryStage.setMinHeight(750);
            primaryStage.setWidth(1440);
            primaryStage.setHeight(900);

            // Load app icon if available
            try {
                primaryStage.getIcons().add(new Image(
                        getClass().getResourceAsStream("/icons/app-icon.png")));
            } catch (Exception ignored) {}

            primaryStage.setOnCloseRequest(e -> {
                e.consume();
                shutdown(primaryStage);
            });

            primaryStage.show();

            // Start monitoring after UI is ready
            Platform.runLater(() -> {
                monitoringService.setResultCallback(result ->
                        Platform.runLater(() -> dashboardView.onCheckResult(result)));
                monitoringService.startMonitoring();
            });

        } catch (Exception e) {
            log.error("Failed to start application", e);
            Platform.exit();
        }
    }

    private void shutdown(Stage stage) {
        log.info("Shutting down...");
        monitoringService.stopAll();
        notificationService.shutdown();
        springContext.close();
        Platform.exit();
        System.exit(0);
    }
}
