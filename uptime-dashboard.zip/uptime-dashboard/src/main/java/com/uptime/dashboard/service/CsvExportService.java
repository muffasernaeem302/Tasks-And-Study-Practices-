package com.uptime.dashboard.service;

import com.uptime.dashboard.model.HealthCheckLog;
import com.uptime.dashboard.model.Incident;
import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.repository.HealthCheckLogRepository;
import com.uptime.dashboard.repository.IncidentRepository;
import com.uptime.dashboard.repository.MonitoredEndpointRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class CsvExportService {

    private final MonitoredEndpointRepository endpointRepo;
    private final HealthCheckLogRepository logRepo;
    private final IncidentRepository incidentRepo;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public String exportHealthLogs(String filePath) throws IOException {
        List<MonitoredEndpoint> endpoints = endpointRepo.findAll();
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath))) {
            pw.println("Endpoint ID,Endpoint Name,URL,Checked At,HTTP Status,Latency (ms),Success,SSL Expiry Days,Error");
            for (MonitoredEndpoint ep : endpoints) {
                List<HealthCheckLog> logs = logRepo.findTop100ByEndpointOrderByCheckedAtDesc(ep);
                for (HealthCheckLog log : logs) {
                    pw.printf("\"%s\",\"%s\",\"%s\",\"%s\",%d,%d,%s,%s,\"%s\"%n",
                            ep.getId(),
                            ep.getName(),
                            ep.getUrl(),
                            log.getCheckedAt().format(FMT),
                            log.getHttpStatusCode() != null ? log.getHttpStatusCode() : 0,
                            log.getLatencyMs() != null ? log.getLatencyMs() : 0,
                            log.isSuccess(),
                            log.getSslExpiryDays() != null ? log.getSslExpiryDays() : "",
                            log.getErrorMessage() != null ? log.getErrorMessage().replace("\"", "'") : ""
                    );
                }
            }
        }
        log.info("Health logs exported to {}", filePath);
        return filePath;
    }

    public String exportIncidents(String filePath) throws IOException {
        List<Incident> incidents = incidentRepo.findAll(
                org.springframework.data.domain.Sort.by(
                        org.springframework.data.domain.Sort.Direction.DESC, "openedAt"));
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath))) {
            pw.println("ID,Endpoint,URL,Status,Opened At,Resolved At,Duration (min),Alert Count,Acknowledged By");
            for (Incident incident : incidents) {
                pw.printf("%d,\"%s\",\"%s\",%s,\"%s\",\"%s\",%s,%d,\"%s\"%n",
                        incident.getId(),
                        incident.getEndpoint().getName(),
                        incident.getEndpoint().getUrl(),
                        incident.getStatus(),
                        incident.getOpenedAt().format(FMT),
                        incident.getResolvedAt() != null ? incident.getResolvedAt().format(FMT) : "",
                        incident.getDurationMinutes() != null ? incident.getDurationMinutes() : "",
                        incident.getAlertCount(),
                        incident.getAcknowledgedBy() != null ? incident.getAcknowledgedBy() : ""
                );
            }
        }
        log.info("Incidents exported to {}", filePath);
        return filePath;
    }
}
