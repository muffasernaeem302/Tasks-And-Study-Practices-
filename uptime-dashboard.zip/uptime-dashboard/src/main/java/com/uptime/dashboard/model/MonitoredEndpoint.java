package com.uptime.dashboard.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

@Entity
@Table(name = "monitored_endpoints")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MonitoredEndpoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, length = 2048)
    private String url;

    @Column(name = "check_interval_seconds")
    @Builder.Default
    private int checkIntervalSeconds = 60;

    @Column(name = "expected_status_code")
    @Builder.Default
    private int expectedStatusCode = 200;

    @Column(name = "timeout_seconds")
    @Builder.Default
    private int timeoutSeconds = 10;

    @Enumerated(EnumType.STRING)
    @Column(name = "current_status")
    @Builder.Default
    private EndpointStatus currentStatus = EndpointStatus.UNKNOWN;

    @Column(name = "last_check_time")
    private LocalDateTime lastCheckTime;

    @Column(name = "last_latency_ms")
    private Long lastLatencyMs;

    @Column(name = "ssl_expiry_days")
    private Integer sslExpiryDays;

    @Column(name = "sla_24h_percent")
    @Builder.Default
    private double sla24hPercent = 100.0;

    @Column(name = "consecutive_failures")
    @Builder.Default
    private int consecutiveFailures = 0;

    @Column(name = "consecutive_successes")
    @Builder.Default
    private int consecutiveSuccesses = 0;

    @Column(name = "enabled")
    @Builder.Default
    private boolean enabled = true;

    @Column(name = "created_at")
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "tags", length = 500)
    private String tags;

    public enum EndpointStatus {
        UP, DOWN, DEGRADED, UNKNOWN
    }
}
