package com.uptime.dashboard.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Entity
@Table(name = "app_settings")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppSettings {

    @Id
    @Column(name = "setting_key", length = 100)
    private String key;

    @Column(name = "setting_value", length = 2048)
    private String value;

    @Column(name = "description", length = 500)
    private String description;

    // Convenience constants for keys
    public static final String DISCORD_WEBHOOK_URL = "discord.webhook.url";
    public static final String SLACK_WEBHOOK_URL = "slack.webhook.url";
    public static final String RE_NOTIFICATION_MINUTES = "re.notification.minutes";
    public static final String DEFAULT_CHECK_INTERVAL = "default.check.interval";
    public static final String SSL_WARNING_DAYS = "ssl.warning.days";
    public static final String DESKTOP_NOTIFICATIONS_ENABLED = "desktop.notifications.enabled";
}
