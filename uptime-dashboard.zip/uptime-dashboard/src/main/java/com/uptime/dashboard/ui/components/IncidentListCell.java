package com.uptime.dashboard.ui.components;

import com.uptime.dashboard.model.Incident;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;

public class IncidentListCell extends ListCell<Incident> {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("MMM d, HH:mm");

    @Override
    protected void updateItem(Incident incident, boolean empty) {
        super.updateItem(incident, empty);
        if (empty || incident == null) {
            setGraphic(null);
            setText(null);
            setStyle("");
            return;
        }

        getStyleClass().add("incident-cell");

        Label title = new Label(incident.getTitle() != null
                ? incident.getTitle() : "Incident #" + incident.getId());
        title.getStyleClass().add("incident-title");

        Label status = new Label(incident.getStatus().name());
        status.getStyleClass().addAll("status-badge",
                switch (incident.getStatus()) {
                    case OPEN -> "down";
                    case ACKNOWLEDGED -> "warn";
                    case RESOLVED -> "up";
                });

        HBox titleRow = new HBox(8, title, status);
        titleRow.setAlignment(Pos.CENTER_LEFT);

        String metaText = "Opened: " + incident.getOpenedAt().format(FMT)
                + "  •  " + incident.getEndpoint().getName();
        if (incident.getStatus() == Incident.IncidentStatus.RESOLVED && incident.getDurationMinutes() != null) {
            metaText += "  •  Duration: " + incident.getDurationMinutes() + "m";
        }
        Label meta = new Label(metaText);
        meta.getStyleClass().add("incident-meta");

        VBox content = new VBox(4, titleRow, meta);
        content.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(content, Priority.ALWAYS);

        HBox row = new HBox(content);
        row.setAlignment(Pos.CENTER_LEFT);

        setGraphic(row);
        setText(null);
    }
}
