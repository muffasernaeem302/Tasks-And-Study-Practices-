package com.uptime.dashboard.ui.components;

import com.uptime.dashboard.model.AppSettings;
import com.uptime.dashboard.repository.AppSettingsRepository;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

public class SettingsDialog extends Dialog<Void> {

    private final AppSettingsRepository settingsRepo;

    private final TextField discordWebhookField = new TextField();
    private final TextField slackWebhookField = new TextField();
    private final Spinner<Integer> reNotifySpinner = new Spinner<>(5, 1440, 60);
    private final Spinner<Integer> sslWarnDaysSpinner = new Spinner<>(1, 365, 30);
    private final CheckBox desktopNotifCheck = new CheckBox("Enable desktop notifications");

    public SettingsDialog(AppSettingsRepository settingsRepo) {
        this.settingsRepo = settingsRepo;

        setTitle("Dashboard Settings");
        setHeaderText("Configure alerts and monitoring preferences");
        getDialogPane().getStyleClass().add("dialog-pane");

        ButtonType saveBtn = new ButtonType("Save Settings", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        getDialogPane().getButtonTypes().addAll(saveBtn, cancelBtn);

        ((Button) getDialogPane().lookupButton(saveBtn)).getStyleClass().add("btn-primary");

        // Load existing values
        discordWebhookField.setText(getSetting(AppSettings.DISCORD_WEBHOOK_URL, ""));
        slackWebhookField.setText(getSetting(AppSettings.SLACK_WEBHOOK_URL, ""));
        reNotifySpinner.getValueFactory().setValue(
                Integer.parseInt(getSetting(AppSettings.RE_NOTIFICATION_MINUTES, "60")));
        sslWarnDaysSpinner.getValueFactory().setValue(
                Integer.parseInt(getSetting(AppSettings.SSL_WARNING_DAYS, "30")));
        desktopNotifCheck.setSelected(
                Boolean.parseBoolean(getSetting(AppSettings.DESKTOP_NOTIFICATIONS_ENABLED, "true")));

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));
        grid.setMinWidth(500);

        discordWebhookField.getStyleClass().add("form-field");
        slackWebhookField.getStyleClass().add("form-field");
        discordWebhookField.setPromptText("https://discord.com/api/webhooks/...");
        slackWebhookField.setPromptText("https://hooks.slack.com/services/...");

        GridPane.setHgrow(discordWebhookField, Priority.ALWAYS);
        GridPane.setHgrow(slackWebhookField, Priority.ALWAYS);

        int row = 0;

        // Section headers
        Label alertSection = new Label("ALERT WEBHOOKS");
        alertSection.getStyleClass().add("section-header");
        grid.add(alertSection, 0, row++, 2, 1);

        grid.add(formLabel("Discord Webhook URL"), 0, row);
        grid.add(discordWebhookField, 1, row++);

        grid.add(formLabel("Slack Webhook URL"), 0, row);
        grid.add(slackWebhookField, 1, row++);

        Separator sep = new Separator();
        grid.add(sep, 0, row++, 2, 1);

        Label monitorSection = new Label("MONITORING BEHAVIOR");
        monitorSection.getStyleClass().add("section-header");
        grid.add(monitorSection, 0, row++, 2, 1);

        grid.add(formLabel("Re-notify after (minutes)"), 0, row);
        grid.add(reNotifySpinner, 1, row++);

        grid.add(formLabel("SSL warning threshold (days)"), 0, row);
        grid.add(sslWarnDaysSpinner, 1, row++);

        grid.add(formLabel("Notifications"), 0, row);
        grid.add(desktopNotifCheck, 1, row++);

        getDialogPane().setContent(grid);

        setResultConverter(btn -> {
            if (btn == saveBtn) {
                saveSetting(AppSettings.DISCORD_WEBHOOK_URL, discordWebhookField.getText().trim(), "Discord webhook URL");
                saveSetting(AppSettings.SLACK_WEBHOOK_URL, slackWebhookField.getText().trim(), "Slack webhook URL");
                saveSetting(AppSettings.RE_NOTIFICATION_MINUTES, String.valueOf(reNotifySpinner.getValue()), "Re-notification interval");
                saveSetting(AppSettings.SSL_WARNING_DAYS, String.valueOf(sslWarnDaysSpinner.getValue()), "SSL warning days");
                saveSetting(AppSettings.DESKTOP_NOTIFICATIONS_ENABLED, String.valueOf(desktopNotifCheck.isSelected()), "Desktop notifications");
            }
            return null;
        });
    }

    private void saveSetting(String key, String value, String description) {
        AppSettings s = settingsRepo.findById(key).orElse(new AppSettings(key, value, description));
        s.setValue(value);
        settingsRepo.save(s);
    }

    private String getSetting(String key, String defaultValue) {
        return settingsRepo.findById(key).map(AppSettings::getValue).orElse(defaultValue);
    }

    private Label formLabel(String text) {
        Label lbl = new Label(text);
        lbl.getStyleClass().add("form-label");
        lbl.setMinWidth(200);
        return lbl;
    }
}
