package com.uptime.dashboard.ui.views;

import com.uptime.dashboard.model.HealthCheckLog;
import com.uptime.dashboard.model.Incident;
import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.repository.AppSettingsRepository;
import com.uptime.dashboard.service.CsvExportService;
import com.uptime.dashboard.service.IncidentService;
import com.uptime.dashboard.service.MonitoringService;
import com.uptime.dashboard.ui.components.*;
import com.uptime.dashboard.util.CheckResult;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Slf4j
@RequiredArgsConstructor
public class MainDashboardView {

    private final MonitoringService monitoringService;
    private final IncidentService incidentService;
    private final CsvExportService csvExportService;
    private final AppSettingsRepository settingsRepo;

    // ---- Metric cards ----
    private MetricCard healthCard;
    private MetricCard outagesCard;
    private MetricCard latencyCard;
    private MetricCard endpointCountCard;

    // ---- Table ----
    private TableView<MonitoredEndpoint> endpointTable;
    private final ObservableList<MonitoredEndpoint> endpointData = FXCollections.observableArrayList();

    // ---- Chart ----
    private LineChart<Number, Number> latencyChart;
    private final Map<Long, XYChart.Series<Number, Number>> chartSeries = new ConcurrentHashMap<>();
    private long chartTick = 0;
    private MonitoredEndpoint selectedChartEndpoint = null;

    // ---- Incident panel ----
    private ListView<Incident> incidentListView;
    private final ObservableList<Incident> incidentData = FXCollections.observableArrayList();

    // ---- Status bar ----
    private Label statusBarLabel;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final int MAX_CHART_POINTS = 60;

    public Scene buildScene() {
        VBox root = new VBox();
        root.getStyleClass().add("dashboard-root");

        // Top bar
        root.getChildren().add(buildTopBar());

        // Metric cards
        root.getChildren().add(buildMetricBar());

        // Main content (split pane: table+chart left, incidents right)
        SplitPane mainContent = buildMainContent();
        VBox.setVgrow(mainContent, Priority.ALWAYS);
        root.getChildren().add(mainContent);

        // Status bar
        root.getChildren().add(buildStatusBar());

        Scene scene = new Scene(root, 1440, 900);
        scene.getStylesheets().add(getClass().getResource("/styles/dashboard.css").toExternalForm());

        // Initial data load
        refreshAll();

        return scene;
    }

    // ============================================================
    // TOP BAR
    // ============================================================
    private HBox buildTopBar() {
        HBox bar = new HBox();
        bar.getStyleClass().add("top-bar");
        bar.setAlignment(Pos.CENTER_LEFT);

        VBox titleBox = new VBox(2);
        Label title = new Label("UPTIME DASHBOARD");
        title.getStyleClass().add("app-title");
        Label subtitle = new Label("Website, SSL & Incident Management");
        subtitle.getStyleClass().add("app-subtitle");
        titleBox.getChildren().addAll(title, subtitle);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addBtn = new Button("+ Add Endpoint");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setOnAction(e -> showAddEndpointDialog());

        Button settingsBtn = new Button("⚙ Settings");
        settingsBtn.getStyleClass().add("btn-secondary");
        settingsBtn.setOnAction(e -> showSettingsDialog());

        Button refreshBtn = new Button("⟳ Refresh All");
        refreshBtn.getStyleClass().add("btn-secondary");
        refreshBtn.setOnAction(e -> refreshAll());

        HBox buttons = new HBox(8, addBtn, refreshBtn, settingsBtn);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        bar.getChildren().addAll(titleBox, spacer, buttons);
        return bar;
    }

    // ============================================================
    // METRIC CARDS BAR
    // ============================================================
    private HBox buildMetricBar() {
        HBox bar = new HBox(12);
        bar.getStyleClass().add("metric-bar");
        bar.setAlignment(Pos.CENTER_LEFT);

        healthCard       = new MetricCard("Overall Health",    "—%",      "info");
        outagesCard      = new MetricCard("Active Outages",    "—",       "down");
        latencyCard      = new MetricCard("Avg. Latency",      "— ms",    "info");
        endpointCountCard = new MetricCard("Monitored Endpoints", "—",    "info");

        // Make cards stretch evenly
        HBox.setHgrow(healthCard, Priority.ALWAYS);
        HBox.setHgrow(outagesCard, Priority.ALWAYS);
        HBox.setHgrow(latencyCard, Priority.ALWAYS);
        HBox.setHgrow(endpointCountCard, Priority.ALWAYS);

        bar.getChildren().addAll(healthCard, outagesCard, latencyCard, endpointCountCard);
        return bar;
    }

    // ============================================================
    // MAIN CONTENT: left=table+chart, right=incidents
    // ============================================================
    private SplitPane buildMainContent() {
        SplitPane split = new SplitPane();
        split.setDividerPositions(0.65);
        VBox.setVgrow(split, Priority.ALWAYS);

        // LEFT: vertical split - table top, chart bottom
        SplitPane leftSplit = new SplitPane();
        leftSplit.setOrientation(javafx.geometry.Orientation.VERTICAL);
        leftSplit.setDividerPositions(0.55);

        VBox tablePanel = buildEndpointTablePanel();
        VBox chartPanel = buildChartPanel();

        leftSplit.getItems().addAll(tablePanel, chartPanel);

        // RIGHT: incidents
        VBox incidentPanel = buildIncidentPanel();

        split.getItems().addAll(leftSplit, incidentPanel);
        return split;
    }

    // ============================================================
    // ENDPOINT TABLE
    // ============================================================
    @SuppressWarnings("unchecked")
    private VBox buildEndpointTablePanel() {
        VBox panel = new VBox();
        panel.getStyleClass().add("section-panel");

        // Panel header
        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(14, 16, 14, 16));
        header.setStyle("-fx-border-color: transparent transparent #2d3748 transparent; -fx-border-width: 0 0 1 0;");

        Label headerLabel = new Label("MONITORED ENDPOINTS");
        headerLabel.getStyleClass().add("section-header");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label hint = new Label("Select row to view latency chart");
        hint.getStyleClass().add("metric-card-label");

        header.getChildren().addAll(headerLabel, spacer, hint);

        // Table
        endpointTable = new TableView<>(endpointData);
        endpointTable.getStyleClass().add("endpoint-table");
        endpointTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        endpointTable.setPlaceholder(new Label("No endpoints configured. Click '+ Add Endpoint' to start."));
        VBox.setVgrow(endpointTable, Priority.ALWAYS);

        // Status column
        TableColumn<MonitoredEndpoint, MonitoredEndpoint.EndpointStatus> statusCol = new TableColumn<>("Status");
        statusCol.setPrefWidth(110);
        statusCol.setMinWidth(100);
        statusCol.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getCurrentStatus()));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(MonitoredEndpoint.EndpointStatus status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) { setGraphic(null); return; }
                StatusBadge badge = new StatusBadge(status);
                setGraphic(badge);
                setText(null);

                // Row highlight
                TableRow<?> row = getTableRow();
                if (row != null) {
                    row.getStyleClass().removeAll("row-down", "row-warn");
                    if (status == MonitoredEndpoint.EndpointStatus.DOWN)
                        row.getStyleClass().add("row-down");
                }
            }
        });

        // Name column
        TableColumn<MonitoredEndpoint, String> nameCol = new TableColumn<>("Name");
        nameCol.setPrefWidth(150);
        nameCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getName()));

        // URL column
        TableColumn<MonitoredEndpoint, String> urlCol = new TableColumn<>("URL");
        urlCol.setPrefWidth(220);
        urlCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getUrl()));
        urlCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String url, boolean empty) {
                super.updateItem(url, empty);
                if (empty || url == null) { setText(null); return; }
                setText(url);
                setTooltip(new Tooltip(url));
                setStyle("-fx-text-fill: #4f8ef7;");
            }
        });

        // Latency column
        TableColumn<MonitoredEndpoint, String> latencyCol = new TableColumn<>("Latency");
        latencyCol.setPrefWidth(90);
        latencyCol.setCellValueFactory(data -> {
            Long ms = data.getValue().getLastLatencyMs();
            return new SimpleStringProperty(ms != null ? ms + " ms" : "—");
        });
        latencyCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); return; }
                setText(val);
                if (!val.equals("—")) {
                    long ms = Long.parseLong(val.replace(" ms", ""));
                    setStyle(ms > 1000 ? "-fx-text-fill: #ff3d71;" :
                             ms > 500  ? "-fx-text-fill: #ffaa00;" :
                                         "-fx-text-fill: #00d68f;");
                }
            }
        });

        // SSL column
        TableColumn<MonitoredEndpoint, String> sslCol = new TableColumn<>("SSL (days)");
        sslCol.setPrefWidth(90);
        sslCol.setCellValueFactory(data -> {
            Integer days = data.getValue().getSslExpiryDays();
            return new SimpleStringProperty(days != null ? String.valueOf(days) : "N/A");
        });
        sslCol.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); return; }
                setText(val);
                if (!val.equals("N/A")) {
                    int days = Integer.parseInt(val);
                    setStyle(days < 7  ? "-fx-text-fill: #ff3d71; -fx-font-weight: bold;" :
                             days < 30 ? "-fx-text-fill: #ffaa00;" :
                                         "-fx-text-fill: #00d68f;");
                } else {
                    setStyle("-fx-text-fill: #8893a4;");
                }
            }
        });

        // SLA column
        TableColumn<MonitoredEndpoint, String> slaCol = new TableColumn<>("24h SLA");
        slaCol.setPrefWidth(80);
        slaCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.format("%.1f%%", data.getValue().getSla24hPercent())));

        // Last checked column
        TableColumn<MonitoredEndpoint, String> lastCheckCol = new TableColumn<>("Last Check");
        lastCheckCol.setPrefWidth(100);
        lastCheckCol.setCellValueFactory(data -> {
            LocalDateTime t = data.getValue().getLastCheckTime();
            return new SimpleStringProperty(t != null ? t.format(TIME_FMT) : "—");
        });

        // Actions column
        TableColumn<MonitoredEndpoint, Void> actionsCol = new TableColumn<>("Actions");
        actionsCol.setPrefWidth(160);
        actionsCol.setMinWidth(150);
        actionsCol.setCellFactory(col -> new TableCell<>() {
            private final Button editBtn    = new Button("Edit");
            private final Button deleteBtn  = new Button("Delete");
            private final Button checkNow   = new Button("↻");
            {
                editBtn.getStyleClass().add("btn-icon");
                deleteBtn.getStyleClass().add("btn-icon");
                checkNow.getStyleClass().add("btn-icon");
                checkNow.setTooltip(new Tooltip("Check now"));

                editBtn.setOnAction(e -> {
                    MonitoredEndpoint ep = getTableRow().getItem();
                    if (ep != null) showEditEndpointDialog(ep);
                });
                deleteBtn.setOnAction(e -> {
                    MonitoredEndpoint ep = getTableRow().getItem();
                    if (ep != null) confirmAndDelete(ep);
                });
                checkNow.setOnAction(e -> {
                    MonitoredEndpoint ep = getTableRow().getItem();
                    if (ep != null) {
                        monitoringService.triggerImmediateCheck(ep.getId());
                        updateStatus("Manual check triggered for: " + ep.getName());
                    }
                });
            }

            @Override
            protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                if (empty) { setGraphic(null); return; }
                HBox box = new HBox(6, checkNow, editBtn, deleteBtn);
                box.setAlignment(Pos.CENTER_LEFT);
                setGraphic(box);
            }
        });

        endpointTable.getColumns().addAll(
                statusCol, nameCol, urlCol, latencyCol, sslCol, slaCol, lastCheckCol, actionsCol);

        // On row selection → update chart
        endpointTable.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                selectedChartEndpoint = selected;
                reloadChartForEndpoint(selected);
            }
        });

        panel.getChildren().addAll(header, endpointTable);
        return panel;
    }

    // ============================================================
    // CHART PANEL
    // ============================================================
    private VBox buildChartPanel() {
        VBox panel = new VBox(12);
        panel.getStyleClass().addAll("section-panel", "chart-panel");

        // Header row with percentile labels
        HBox chartHeader = new HBox(12);
        chartHeader.setAlignment(Pos.CENTER_LEFT);

        Label chartTitle = new Label("LATENCY TREND (ms)");
        chartTitle.getStyleClass().add("section-header");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label p95Label = new Label("p95: —");
        p95Label.getStyleClass().addAll("percentile-label", "p95-label");
        p95Label.setId("p95Label");

        Label p99Label = new Label("p99: —");
        p99Label.getStyleClass().addAll("percentile-label", "p99-label");
        p99Label.setId("p99Label");

        Label endpointNameLabel = new Label("No endpoint selected");
        endpointNameLabel.getStyleClass().add("metric-card-label");
        endpointNameLabel.setId("chartEndpointLabel");

        chartHeader.getChildren().addAll(chartTitle, endpointNameLabel, spacer, p95Label, p99Label);

        // Chart
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Checks (recent →)");
        xAxis.setTickLabelsVisible(false);
        xAxis.setTickMarkVisible(false);
        xAxis.setMinorTickVisible(false);

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Latency (ms)");
        yAxis.setAutoRanging(true);
        yAxis.setForceZeroInRange(true);

        latencyChart = new LineChart<>(xAxis, yAxis);
        latencyChart.getStyleClass().add("latency-chart");
        latencyChart.setAnimated(false);
        latencyChart.setCreateSymbols(true);
        latencyChart.setLegendVisible(true);
        VBox.setVgrow(latencyChart, Priority.ALWAYS);

        panel.getChildren().addAll(chartHeader, latencyChart);
        return panel;
    }

    // ============================================================
    // INCIDENT PANEL
    // ============================================================
    private VBox buildIncidentPanel() {
        VBox panel = new VBox();
        panel.getStyleClass().add("incident-panel");

        // Header
        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(14, 16, 14, 16));
        header.setStyle("-fx-border-color: transparent transparent #2d3748 transparent; -fx-border-width: 0 0 1 0;");

        Label title = new Label("INCIDENTS");
        title.getStyleClass().add("section-header");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        ToggleGroup viewToggle = new ToggleGroup();
        ToggleButton activeBtn = new ToggleButton("Active");
        ToggleButton allBtn = new ToggleButton("All");
        activeBtn.setToggleGroup(viewToggle);
        allBtn.setToggleGroup(viewToggle);
        activeBtn.setSelected(true);
        activeBtn.getStyleClass().add("btn-secondary");
        allBtn.getStyleClass().add("btn-secondary");

        activeBtn.setOnAction(e -> refreshIncidents(false));
        allBtn.setOnAction(e -> refreshIncidents(true));

        header.getChildren().addAll(title, spacer, activeBtn, allBtn);

        // Incident list
        incidentListView = new ListView<>(incidentData);
        incidentListView.getStyleClass().add("incident-list");
        incidentListView.setCellFactory(lv -> new IncidentListCell());
        incidentListView.setPlaceholder(new Label("No active incidents. All systems nominal."));
        VBox.setVgrow(incidentListView, Priority.ALWAYS);

        // Action buttons
        HBox actions = new HBox(8);
        actions.setPadding(new Insets(12, 16, 12, 16));
        actions.setAlignment(Pos.CENTER_LEFT);
        actions.setStyle("-fx-border-color: #2d3748 transparent transparent transparent; -fx-border-width: 1 0 0 0;");

        Button ackBtn = new Button("✓ Acknowledge");
        ackBtn.getStyleClass().add("btn-secondary");
        ackBtn.setOnAction(e -> acknowledgeSelected());

        Button exportBtn = new Button("⬇ Export CSV");
        exportBtn.getStyleClass().add("btn-secondary");
        exportBtn.setOnAction(e -> showExportMenu());

        Region btnSpacer = new Region();
        HBox.setHgrow(btnSpacer, Priority.ALWAYS);

        actions.getChildren().addAll(ackBtn, btnSpacer, exportBtn);

        panel.getChildren().addAll(header, incidentListView, actions);
        return panel;
    }

    // ============================================================
    // STATUS BAR
    // ============================================================
    private HBox buildStatusBar() {
        HBox bar = new HBox();
        bar.getStyleClass().add("status-bar");
        bar.setAlignment(Pos.CENTER_LEFT);

        statusBarLabel = new Label("Ready");
        statusBarLabel.getStyleClass().add("status-bar-text");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label clockLabel = new Label();
        clockLabel.getStyleClass().add("status-bar-text");

        // Update clock every second
        javafx.animation.Timeline clock = new javafx.animation.Timeline(
                new javafx.animation.KeyFrame(javafx.util.Duration.seconds(1), e ->
                        clockLabel.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))));
        clock.setCycleCount(javafx.animation.Animation.INDEFINITE);
        clock.play();

        bar.getChildren().addAll(statusBarLabel, spacer, clockLabel);
        return bar;
    }

    // ============================================================
    // DATA REFRESH
    // ============================================================
    public void refreshAll() {
        refreshEndpointTable();
        refreshMetricCards();
        refreshIncidents(false);
    }

    private void refreshEndpointTable() {
        List<MonitoredEndpoint> endpoints = monitoringService.getAllEndpoints();
        endpointData.setAll(endpoints);
        updateStatus("Loaded " + endpoints.size() + " endpoints");
    }

    private void refreshMetricCards() {
        double health = monitoringService.getOverallHealth();
        long outages = monitoringService.countActiveOutages();
        Double avgLat = monitoringService.getAverageLatency();
        long total = monitoringService.countMonitoredEndpoints();

        healthCard.setValue(String.format("%.1f%%", health));
        healthCard.setStyleVariant(health >= 99 ? "up" : health >= 95 ? "warn" : "down");

        outagesCard.setValue(String.valueOf(outages));
        outagesCard.setStyleVariant(outages == 0 ? "up" : "down");

        latencyCard.setValue(avgLat != null ? Math.round(avgLat) + " ms" : "— ms");

        endpointCountCard.setValue(String.valueOf(total));
    }

    private void refreshIncidents(boolean all) {
        List<Incident> incidents = all
                ? incidentService.getAllIncidents()
                : incidentService.getActiveIncidents();
        incidentData.setAll(incidents);
    }

    // Called from monitoring engine via Platform.runLater
    public void onCheckResult(CheckResult result) {
        // Refresh the specific endpoint row
        endpointData.replaceAll(ep -> {
            if (ep.getId().equals(result.getEndpointId())) {
                ep.setCurrentStatus(result.getStatus());
                ep.setLastLatencyMs(result.getLatencyMs());
                ep.setLastCheckTime(result.getCheckedAt());
                if (result.getSslExpiryDays() != null) ep.setSslExpiryDays(result.getSslExpiryDays());
            }
            return ep;
        });
        endpointTable.refresh();
        refreshMetricCards();
        refreshIncidents(false);

        // Update chart if this is the selected endpoint
        if (selectedChartEndpoint != null
                && selectedChartEndpoint.getId().equals(result.getEndpointId())) {
            appendChartPoint(result);
        }

        updateStatus("Updated: " + result.getCheckedAt().format(TIME_FMT)
                + " — " + (result.isSuccess() ? "✓" : "✗"));
    }

    // ============================================================
    // CHART HELPERS
    // ============================================================
    private void reloadChartForEndpoint(MonitoredEndpoint endpoint) {
        latencyChart.getData().clear();
        chartSeries.clear();
        chartTick = 0;

        // Update labels
        Label nameLabel = (Label) latencyChart.getScene().lookup("#chartEndpointLabel");
        if (nameLabel != null) nameLabel.setText(endpoint.getName());

        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName(endpoint.getName());
        chartSeries.put(endpoint.getId(), series);
        latencyChart.getData().add(series);

        // Load historical data
        List<HealthCheckLog> logs = monitoringService.getRecentLogs(endpoint);
        // Reverse for ascending time order
        for (int i = logs.size() - 1; i >= 0; i--) {
            HealthCheckLog log = logs.get(i);
            if (log.getLatencyMs() != null) {
                series.getData().add(new XYChart.Data<>(chartTick++, log.getLatencyMs()));
            }
        }

        // Trim to max points
        while (series.getData().size() > MAX_CHART_POINTS) {
            series.getData().remove(0);
        }

        updatePercentileLabels(endpoint.getId());
    }

    private void appendChartPoint(CheckResult result) {
        XYChart.Series<Number, Number> series = chartSeries.get(result.getEndpointId());
        if (series == null) return;

        series.getData().add(new XYChart.Data<>(chartTick++, result.getLatencyMs()));
        if (series.getData().size() > MAX_CHART_POINTS) {
            series.getData().remove(0);
        }

        updatePercentileLabels(result.getEndpointId());
    }

    private void updatePercentileLabels(Long endpointId) {
        Double p95 = monitoringService.getP95Latency(endpointId);
        Double p99 = monitoringService.getP99Latency(endpointId);

        Label p95Lbl = (Label) latencyChart.getScene().lookup("#p95Label");
        Label p99Lbl = (Label) latencyChart.getScene().lookup("#p99Label");

        if (p95Lbl != null) p95Lbl.setText("p95: " + (p95 != null ? Math.round(p95) + " ms" : "—"));
        if (p99Lbl != null) p99Lbl.setText("p99: " + (p99 != null ? Math.round(p99) + " ms" : "—"));
    }

    // ============================================================
    // ACTIONS
    // ============================================================
    private void showAddEndpointDialog() {
        EndpointFormDialog.showAdd().ifPresent(endpoint -> {
            monitoringService.saveEndpoint(endpoint);
            refreshAll();
            updateStatus("Endpoint added: " + endpoint.getName());
        });
    }

    private void showEditEndpointDialog(MonitoredEndpoint endpoint) {
        EndpointFormDialog.showEdit(endpoint).ifPresent(updated -> {
            monitoringService.saveEndpoint(updated);
            refreshAll();
            updateStatus("Endpoint updated: " + updated.getName());
        });
    }

    private void confirmAndDelete(MonitoredEndpoint endpoint) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Endpoint");
        confirm.setHeaderText("Delete \"" + endpoint.getName() + "\"?");
        confirm.setContentText("All health check logs and incidents for this endpoint will be retained, "
                + "but monitoring will stop immediately.");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                monitoringService.deleteEndpoint(endpoint.getId());
                refreshAll();
                updateStatus("Endpoint deleted: " + endpoint.getName());
            }
        });
    }

    private void acknowledgeSelected() {
        Incident selected = incidentListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Select an incident to acknowledge.");
            return;
        }
        if (selected.getStatus() == Incident.IncidentStatus.RESOLVED) {
            showInfo("This incident is already resolved.");
            return;
        }
        incidentService.acknowledgeIncident(selected.getId(), "Dashboard User");
        refreshIncidents(false);
        updateStatus("Incident #" + selected.getId() + " acknowledged");
    }

    private void showExportMenu() {
        ContextMenu menu = new ContextMenu();

        MenuItem exportLogs = new MenuItem("Export Health Logs (CSV)");
        exportLogs.setOnAction(e -> exportCsv("health_logs"));

        MenuItem exportIncidents = new MenuItem("Export Incidents (CSV)");
        exportIncidents.setOnAction(e -> exportCsv("incidents"));

        menu.getItems().addAll(exportLogs, exportIncidents);

        Button exportBtn = (Button) endpointTable.getScene().lookup(".btn-secondary");
        menu.show(endpointTable.getScene().getWindow(), 0, 0);
    }

    private void exportCsv(String type) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Save CSV Export");
        chooser.setInitialFileName(type + "_export_"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm")) + ".csv");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));

        Stage stage = (Stage) endpointTable.getScene().getWindow();
        File file = chooser.showSaveDialog(stage);
        if (file == null) return;

        try {
            if (type.equals("health_logs")) {
                csvExportService.exportHealthLogs(file.getAbsolutePath());
            } else {
                csvExportService.exportIncidents(file.getAbsolutePath());
            }
            updateStatus("Exported to: " + file.getName());
            showInfo("Export complete: " + file.getAbsolutePath());
        } catch (Exception ex) {
            log.error("Export failed", ex);
            showError("Export failed: " + ex.getMessage());
        }
    }

    private void showSettingsDialog() {
        new SettingsDialog(settingsRepo).showAndWait();
        updateStatus("Settings saved");
    }

    // ============================================================
    // UTILITY
    // ============================================================
    private void updateStatus(String msg) {
        Platform.runLater(() -> statusBarLabel.setText(msg));
    }

    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText("Error");
        a.showAndWait();
    }
}
