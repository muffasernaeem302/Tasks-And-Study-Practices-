package com.uptime.dashboard.config;

import com.uptime.dashboard.model.AppSettings;
import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.repository.AppSettingsRepository;
import com.uptime.dashboard.repository.MonitoredEndpointRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class DataSeeder implements ApplicationRunner {

    private final MonitoredEndpointRepository endpointRepo;
    private final AppSettingsRepository settingsRepo;

    @Override
    public void run(ApplicationArguments args) {
        seedDefaultSettings();
        seedDemoEndpoints();
    }

    private void seedDefaultSettings() {
        saveIfAbsent(AppSettings.DISCORD_WEBHOOK_URL, "", "Discord webhook URL for alerts");
        saveIfAbsent(AppSettings.SLACK_WEBHOOK_URL, "", "Slack webhook URL for alerts");
        saveIfAbsent(AppSettings.RE_NOTIFICATION_MINUTES, "60", "Minutes between repeat alerts");
        saveIfAbsent(AppSettings.SSL_WARNING_DAYS, "30", "Days before SSL expiry to warn");
        saveIfAbsent(AppSettings.DESKTOP_NOTIFICATIONS_ENABLED, "true", "Show desktop OS notifications");
    }

    private void seedDemoEndpoints() {
        if (endpointRepo.count() > 0) {
            log.info("Endpoints already exist, skipping demo seed");
            return;
        }

        log.info("Seeding demo endpoints...");

        endpointRepo.save(MonitoredEndpoint.builder()
                .name("GitHub")
                .url("https://github.com")
                .checkIntervalSeconds(60)
                .expectedStatusCode(200)
                .timeoutSeconds(10)
                .enabled(true)
                .build());

        endpointRepo.save(MonitoredEndpoint.builder()
                .name("Cloudflare DNS")
                .url("https://1.1.1.1")
                .checkIntervalSeconds(30)
                .expectedStatusCode(200)
                .timeoutSeconds(5)
                .enabled(true)
                .build());

        endpointRepo.save(MonitoredEndpoint.builder()
                .name("Anthropic API")
                .url("https://api.anthropic.com")
                .checkIntervalSeconds(120)
                .expectedStatusCode(200)
                .timeoutSeconds(10)
                .enabled(true)
                .build());

        endpointRepo.save(MonitoredEndpoint.builder()
                .name("Google")
                .url("https://www.google.com")
                .checkIntervalSeconds(60)
                .expectedStatusCode(200)
                .timeoutSeconds(8)
                .enabled(true)
                .build());

        log.info("Demo endpoints seeded successfully");
    }

    private void saveIfAbsent(String key, String value, String description) {
        if (!settingsRepo.existsById(key)) {
            settingsRepo.save(new AppSettings(key, value, description));
        }
    }
}
