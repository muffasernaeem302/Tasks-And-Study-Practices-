package com.uptime.dashboard.service;

import com.uptime.dashboard.model.AppSettings;
import com.uptime.dashboard.model.HealthCheckLog;
import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.repository.AppSettingsRepository;
import com.uptime.dashboard.repository.HealthCheckLogRepository;
import com.uptime.dashboard.repository.MonitoredEndpointRepository;
import com.uptime.dashboard.util.CheckResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@Service
@Slf4j
@RequiredArgsConstructor
public class MonitoringService {

    private final MonitoredEndpointRepository endpointRepo;
    private final HealthCheckLogRepository logRepo;
    private final AppSettingsRepository settingsRepo;
    private final HttpCheckService httpCheckService;
    private final IncidentService incidentService;
    private final WebhookService webhookService;

    // Virtual thread executor for background checks
    private final java.util.concurrent.ExecutorService virtualThreadExecutor =
            Executors.newVirtualThreadPerTaskExecutor();

    // Scheduler for periodic triggers (lightweight, just dispatches to VT executor)
    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(1, Thread.ofVirtual().factory());

    private final ConcurrentHashMap<Long, ScheduledFuture<?>> scheduledTasks = new ConcurrentHashMap<>();

    // Callback for UI to be notified of new results
    private Consumer<CheckResult> resultCallback;

    public void setResultCallback(Consumer<CheckResult> callback) {
        this.resultCallback = callback;
    }

    public void startMonitoring() {
        List<MonitoredEndpoint> endpoints = endpointRepo.findByEnabledTrue();
        log.info("Starting monitoring for {} endpoints", endpoints.size());
        endpoints.forEach(this::scheduleEndpoint);
    }

    public void scheduleEndpoint(MonitoredEndpoint endpoint) {
        stopMonitoringEndpoint(endpoint.getId());

        ScheduledFuture<?> future = scheduler.scheduleAtFixedRate(
                () -> executeCheck(endpoint.getId()),
                0,
                endpoint.getCheckIntervalSeconds(),
                TimeUnit.SECONDS
        );
        scheduledTasks.put(endpoint.getId(), future);
        log.debug("Scheduled endpoint {} every {}s", endpoint.getName(), endpoint.getCheckIntervalSeconds());
    }

    public void stopMonitoringEndpoint(Long endpointId) {
        ScheduledFuture<?> existing = scheduledTasks.remove(endpointId);
        if (existing != null) {
            existing.cancel(false);
        }
    }

    public void triggerImmediateCheck(Long endpointId) {
        virtualThreadExecutor.submit(() -> executeCheck(endpointId));
    }

    private void executeCheck(Long endpointId) {
        MonitoredEndpoint endpoint = endpointRepo.findById(endpointId).orElse(null);
        if (endpoint == null || !endpoint.isEnabled()) return;

        // Run actual check on virtual thread
        virtualThreadExecutor.submit(() -> {
            CheckResult result = httpCheckService.check(endpoint);
            processResult(endpoint, result);
        });
    }

    @Transactional
    protected void processResult(MonitoredEndpoint endpoint, CheckResult result) {
        // Reload fresh from DB to avoid stale state
        MonitoredEndpoint fresh = endpointRepo.findById(endpoint.getId()).orElse(endpoint);

        // Update consecutive counters
        if (result.isSuccess()) {
            fresh.setConsecutiveSuccesses(fresh.getConsecutiveSuccesses() + 1);
            fresh.setConsecutiveFailures(0);
        } else {
            fresh.setConsecutiveFailures(fresh.getConsecutiveFailures() + 1);
            fresh.setConsecutiveSuccesses(0);
        }

        // Determine new status
        int failThreshold = 2;
        int successThreshold = 2;
        MonitoredEndpoint.EndpointStatus previousStatus = fresh.getCurrentStatus();

        if (fresh.getConsecutiveFailures() >= failThreshold) {
            fresh.setCurrentStatus(MonitoredEndpoint.EndpointStatus.DOWN);
        } else if (fresh.getConsecutiveSuccesses() >= successThreshold) {
            fresh.setCurrentStatus(MonitoredEndpoint.EndpointStatus.UP);
        } else if (result.isSuccess()) {
            // Still within grace period, keep as UP or UNKNOWN
            if (previousStatus == MonitoredEndpoint.EndpointStatus.UNKNOWN) {
                fresh.setCurrentStatus(MonitoredEndpoint.EndpointStatus.UNKNOWN);
            }
        }

        // Update endpoint fields
        fresh.setLastCheckTime(result.getCheckedAt());
        fresh.setLastLatencyMs(result.getLatencyMs());
        if (result.getSslExpiryDays() != null) {
            fresh.setSslExpiryDays(result.getSslExpiryDays());
        }

        // Recalculate 24h SLA
        double sla = calculateSla24h(fresh);
        fresh.setSla24hPercent(sla);

        endpointRepo.save(fresh);

        // Persist the log entry
        HealthCheckLog logEntry = HealthCheckLog.builder()
                .endpoint(fresh)
                .checkedAt(result.getCheckedAt())
                .httpStatusCode(result.getHttpStatusCode())
                .latencyMs(result.getLatencyMs())
                .success(result.isSuccess())
                .errorMessage(result.getErrorMessage())
                .sslExpiryDays(result.getSslExpiryDays())
                .statusAtCheck(fresh.getCurrentStatus())
                .build();
        logRepo.save(logEntry);

        // Incident lifecycle
        if (fresh.getCurrentStatus() == MonitoredEndpoint.EndpointStatus.DOWN
                && previousStatus != MonitoredEndpoint.EndpointStatus.DOWN) {
            incidentService.openIncident(fresh, result.getErrorMessage());
        } else if (fresh.getCurrentStatus() == MonitoredEndpoint.EndpointStatus.DOWN) {
            incidentService.openIncident(fresh, result.getErrorMessage()); // handles throttle internally
        } else if (fresh.getCurrentStatus() == MonitoredEndpoint.EndpointStatus.UP
                && previousStatus == MonitoredEndpoint.EndpointStatus.DOWN) {
            incidentService.resolveIncident(fresh);
        }

        // SSL expiry alert
        if (result.getSslExpiryDays() != null && result.getSslExpiryDays() <= 30
                && result.getSslExpiryDays() > 0) {
            int sslWarningDays = settingsRepo.findById(AppSettings.SSL_WARNING_DAYS)
                    .map(s -> Integer.parseInt(s.getValue())).orElse(30);
            if (result.getSslExpiryDays() <= sslWarningDays) {
                webhookService.sendSslWarningAlert(fresh, result.getSslExpiryDays());
            }
        }

        // Notify UI
        if (resultCallback != null) {
            resultCallback.accept(result);
        }
    }

    private double calculateSla24h(MonitoredEndpoint endpoint) {
        LocalDateTime since = LocalDateTime.now().minusHours(24);
        long total = logRepo.countTotalChecks(endpoint, since);
        if (total == 0) return 100.0;
        long successful = logRepo.countSuccessfulChecks(endpoint, since);
        return Math.round((successful * 100.0 / total) * 100.0) / 100.0;
    }

    public void stopAll() {
        log.info("Stopping all monitoring tasks");
        scheduledTasks.values().forEach(f -> f.cancel(false));
        scheduledTasks.clear();
        scheduler.shutdownNow();
        virtualThreadExecutor.shutdownNow();
    }

    @Transactional
    public MonitoredEndpoint saveEndpoint(MonitoredEndpoint endpoint) {
        MonitoredEndpoint saved = endpointRepo.save(endpoint);
        if (saved.isEnabled()) {
            scheduleEndpoint(saved);
        }
        return saved;
    }

    @Transactional
    public void deleteEndpoint(Long id) {
        stopMonitoringEndpoint(id);
        endpointRepo.deleteById(id);
    }

    public List<MonitoredEndpoint> getAllEndpoints() {
        return endpointRepo.findAll();
    }

    public List<HealthCheckLog> getRecentLogs(MonitoredEndpoint endpoint) {
        return logRepo.findTop100ByEndpointOrderByCheckedAtDesc(endpoint);
    }

    public List<HealthCheckLog> getLogs24h(MonitoredEndpoint endpoint) {
        return logRepo.findByEndpointAndCheckedAtAfter(endpoint, LocalDateTime.now().minusHours(24));
    }

    public Double getP95Latency(Long endpointId) {
        return logRepo.calculateP95Latency(endpointId, LocalDateTime.now().minusHours(24));
    }

    public Double getP99Latency(Long endpointId) {
        return logRepo.calculateP99Latency(endpointId, LocalDateTime.now().minusHours(24));
    }

    public long countActiveOutages() {
        return endpointRepo.countActiveOutages();
    }

    public Double getAverageLatency() {
        return endpointRepo.averageLatency();
    }

    public long countMonitoredEndpoints() {
        return endpointRepo.count();
    }

    public double getOverallHealth() {
        List<MonitoredEndpoint> all = endpointRepo.findByEnabledTrue();
        if (all.isEmpty()) return 100.0;
        long up = all.stream()
                .filter(e -> e.getCurrentStatus() == MonitoredEndpoint.EndpointStatus.UP)
                .count();
        return Math.round((up * 100.0 / all.size()) * 10.0) / 10.0;
    }
}
