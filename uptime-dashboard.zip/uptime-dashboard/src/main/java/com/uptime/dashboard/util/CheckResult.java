package com.uptime.dashboard.util;

import com.uptime.dashboard.model.MonitoredEndpoint;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class CheckResult {
    private Long endpointId;
    private boolean success;
    private int httpStatusCode;
    private long latencyMs;
    private String errorMessage;
    private Integer sslExpiryDays;
    private MonitoredEndpoint.EndpointStatus status;
    private LocalDateTime checkedAt;
}
