package com.uptime.dashboard.service;

import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.util.CheckResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class HttpCheckService {

    /**
     * Performs a full HTTP + SSL health check on the given endpoint.
     * This method is designed to be called from Virtual Threads.
     */
    public CheckResult check(MonitoredEndpoint endpoint) {
        long startTime = System.currentTimeMillis();
        AtomicInteger capturedStatus = new AtomicInteger(0);
        AtomicReference<Integer> sslDays = new AtomicReference<>(null);

        try {
            // Custom SSL context to inspect certificates during handshake
            SSLContext sslContext = buildSslContextWithCertInspector(endpoint.getUrl(), sslDays);

            HttpClient client = HttpClient.newBuilder()
                    .sslContext(sslContext)
                    .connectTimeout(Duration.ofSeconds(endpoint.getTimeoutSeconds()))
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .version(HttpClient.Version.HTTP_1_1)
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(endpoint.getUrl()))
                    .timeout(Duration.ofSeconds(endpoint.getTimeoutSeconds()))
                    .GET()
                    .header("User-Agent", "UptimeDashboard/1.0")
                    .build();

            HttpResponse<Void> response = client.send(request, HttpResponse.BodyHandlers.discarding());
            long latency = System.currentTimeMillis() - startTime;
            int statusCode = response.statusCode();

            boolean success = statusCode == endpoint.getExpectedStatusCode() ||
                    (endpoint.getExpectedStatusCode() == 200 && statusCode >= 200 && statusCode < 400);

            MonitoredEndpoint.EndpointStatus status = success
                    ? MonitoredEndpoint.EndpointStatus.UP
                    : MonitoredEndpoint.EndpointStatus.DOWN;

            return CheckResult.builder()
                    .endpointId(endpoint.getId())
                    .success(success)
                    .httpStatusCode(statusCode)
                    .latencyMs(latency)
                    .sslExpiryDays(sslDays.get())
                    .status(status)
                    .checkedAt(LocalDateTime.now())
                    .build();

        } catch (Exception e) {
            long latency = System.currentTimeMillis() - startTime;
            String errorMsg = sanitizeError(e);
            log.debug("Check failed for {}: {}", endpoint.getUrl(), errorMsg);

            return CheckResult.builder()
                    .endpointId(endpoint.getId())
                    .success(false)
                    .httpStatusCode(0)
                    .latencyMs(latency)
                    .errorMessage(errorMsg)
                    .sslExpiryDays(sslDays.get())
                    .status(MonitoredEndpoint.EndpointStatus.DOWN)
                    .checkedAt(LocalDateTime.now())
                    .build();
        }
    }

    private SSLContext buildSslContextWithCertInspector(String url, AtomicReference<Integer> sslDays) throws Exception {
        if (!url.startsWith("https://")) {
            return SSLContext.getDefault();
        }

        X509TrustManager defaultTm = getDefaultTrustManager();

        X509TrustManager inspectingTm = new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
                defaultTm.checkClientTrusted(chain, authType);
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
                defaultTm.checkServerTrusted(chain, authType);
                if (chain != null && chain.length > 0) {
                    Date expiryDate = chain[0].getNotAfter();
                    long daysLeft = Duration.between(
                            LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant(),
                            expiryDate.toInstant()
                    ).toDays();
                    sslDays.set((int) daysLeft);
                }
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return defaultTm.getAcceptedIssuers();
            }
        };

        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, new TrustManager[]{inspectingTm}, null);
        return ctx;
    }

    private X509TrustManager getDefaultTrustManager() throws Exception {
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init((java.security.KeyStore) null);
        for (TrustManager tm : tmf.getTrustManagers()) {
            if (tm instanceof X509TrustManager x509tm) {
                return x509tm;
            }
        }
        throw new IllegalStateException("No X509TrustManager found");
    }

    private String sanitizeError(Exception e) {
        if (e instanceof java.net.ConnectException) return "Connection refused";
        if (e instanceof java.net.SocketTimeoutException) return "Timeout";
        if (e instanceof java.net.UnknownHostException) return "Unknown host";
        if (e instanceof SSLHandshakeException) return "SSL handshake failed";
        if (e instanceof IOException) return "Network error: " + e.getMessage();
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }
}
