package com.uptime.dashboard.service;

import com.uptime.dashboard.model.AppSettings;
import com.uptime.dashboard.repository.AppSettingsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.awt.TrayIcon.MessageType;

@Service
@Slf4j
@RequiredArgsConstructor
public class NotificationService {

    private final AppSettingsRepository settingsRepo;
    private TrayIcon trayIcon;
    private boolean traySupported = false;

    public void initialize() {
        if (!SystemTray.isSupported()) {
            log.warn("SystemTray not supported on this platform");
            return;
        }
        try {
            SystemTray tray = SystemTray.getSystemTray();
            Image image = Toolkit.getDefaultToolkit()
                    .createImage(getClass().getResource("/icons/tray-icon.png"));
            if (image == null) {
                // Create a simple programmatic icon if resource not found
                image = createDefaultTrayImage();
            }

            trayIcon = new TrayIcon(image, "Uptime Dashboard");
            trayIcon.setImageAutoSize(true);
            tray.add(trayIcon);
            traySupported = true;
            log.info("System tray icon initialized");
        } catch (Exception e) {
            log.warn("Failed to initialize system tray: {}", e.getMessage());
        }
    }

    public void sendDesktopAlert(String title, String message) {
        if (!isDesktopNotificationsEnabled()) return;
        if (!traySupported || trayIcon == null) return;

        // Determine message type based on title content
        MessageType type = title.contains("DOWN") ? MessageType.ERROR
                : title.contains("RECOVERED") ? MessageType.INFO
                : MessageType.WARNING;

        trayIcon.displayMessage(title, message, type);
        log.debug("Desktop notification sent: {}", title);
    }

    private boolean isDesktopNotificationsEnabled() {
        return settingsRepo.findById(AppSettings.DESKTOP_NOTIFICATIONS_ENABLED)
                .map(s -> Boolean.parseBoolean(s.getValue()))
                .orElse(true);
    }

    private Image createDefaultTrayImage() {
        // Create a simple 16x16 green dot as default icon
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(16, 16,
                java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(0, 200, 81));
        g.fillOval(1, 1, 14, 14);
        g.dispose();
        return img;
    }

    public void shutdown() {
        if (traySupported && trayIcon != null) {
            try {
                SystemTray.getSystemTray().remove(trayIcon);
            } catch (Exception ignored) {}
        }
    }
}
