package com.uptime.dashboard.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptime.dashboard.model.AppSettings;
import com.uptime.dashboard.model.Incident;
import com.uptime.dashboard.model.MonitoredEndpoint;
import com.uptime.dashboard.repository.AppSettingsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class WebhookService {

    private final AppSettingsRepository settingsRepo;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public void sendDownAlert(MonitoredEndpoint endpoint, Incident incident) {
        String title = "🔴 DOWN: " + endpoint.getName();
        String description = String.format(
                "**%s** is DOWN\n**URL:** %s\n**Since:** %s\n**Error:** %s",
                endpoint.getName(),
                endpoint.getUrl(),
                incident.getOpenedAt(),
                incident.getDescription() != null ? incident.getDescription() : "No response"
        );
        sendToAll(title, description, 0xFF0000); // Red
    }

    public void sendRecoveryAlert(MonitoredEndpoint endpoint) {
        String title = "✅ RECOVERED: " + endpoint.getName();
        String description = String.format(
                "**%s** is back UP\n**URL:** %s\n**Latency:** %d ms",
                endpoint.getName(),
                endpoint.getUrl(),
                endpoint.getLastLatencyMs() != null ? endpoint.getLastLatencyMs() : 0
        );
        sendToAll(title, description, 0x00C851); // Green
    }

    public void sendSslWarningAlert(MonitoredEndpoint endpoint, int daysRemaining) {
        String title = "⚠️ SSL Warning: " + endpoint.getName();
        String description = String.format(
                "**%s** SSL certificate expires in **%d days**\n**URL:** %s",
                endpoint.getName(), daysRemaining, endpoint.getUrl()
        );
        sendToAll(title, description, 0xFFAA00); // Orange
    }

    private void sendToAll(String title, String description, int color) {
        sendDiscord(title, description, color);
        sendSlack(title, description);
    }

    private void sendDiscord(String title, String description, int color) {
        String webhookUrl = getSetting(AppSettings.DISCORD_WEBHOOK_URL);
        if (webhookUrl == null || webhookUrl.isBlank()) return;

        try {
            Map<String, Object> embed = Map.of(
                    "title", title,
                    "description", description,
                    "color", color
            );
            Map<String, Object> payload = Map.of("embeds", new Object[]{embed});
            String json = objectMapper.writeValueAsString(payload);
            post(webhookUrl, json);
            log.info("Discord alert sent: {}", title);
        } catch (Exception e) {
            log.warn("Failed to send Discord alert: {}", e.getMessage());
        }
    }

    private void sendSlack(String title, String description) {
        String webhookUrl = getSetting(AppSettings.SLACK_WEBHOOK_URL);
        if (webhookUrl == null || webhookUrl.isBlank()) return;

        try {
            Map<String, Object> payload = Map.of(
                    "text", "*" + title + "*\n" + description.replace("**", "*")
            );
            String json = objectMapper.writeValueAsString(payload);
            post(webhookUrl, json);
            log.info("Slack alert sent: {}", title);
        } catch (Exception e) {
            log.warn("Failed to send Slack alert: {}", e.getMessage());
        }
    }

    private void post(String url, String jsonBody) throws Exception {
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 400) {
            log.warn("Webhook returned HTTP {}", response.statusCode());
        }
    }

    private String getSetting(String key) {
        return settingsRepo.findById(key).map(AppSettings::getValue).orElse(null);
    }
}
