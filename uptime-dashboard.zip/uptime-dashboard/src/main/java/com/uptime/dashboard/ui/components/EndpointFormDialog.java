package com.uptime.dashboard.ui.components;

import com.uptime.dashboard.model.MonitoredEndpoint;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import java.util.Optional;

public class EndpointFormDialog extends Dialog<MonitoredEndpoint> {

    private final TextField nameField = new TextField();
    private final TextField urlField = new TextField();
    private final Spinner<Integer> intervalSpinner = new Spinner<>(10, 3600, 60);
    private final Spinner<Integer> statusCodeSpinner = new Spinner<>(100, 599, 200);
    private final Spinner<Integer> timeoutSpinner = new Spinner<>(3, 60, 10);
    private final TextField tagsField = new TextField();
    private final CheckBox enabledCheck = new CheckBox("Enabled");

    public EndpointFormDialog(MonitoredEndpoint existing) {
        setTitle(existing == null ? "Add Endpoint" : "Edit Endpoint");
        setHeaderText(existing == null ? "Monitor a new endpoint" : "Update endpoint configuration");

        getDialogPane().getStyleClass().add("dialog-pane");
        getDialogPane().getScene().getRoot().getStylesheets().add(
                getClass().getResource("/styles/dashboard.css").toExternalForm());

        ButtonType saveButton = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        getDialogPane().getButtonTypes().addAll(saveButton, cancelButton);

        // Style the save button
        Button saveBtn = (Button) getDialogPane().lookupButton(saveButton);
        saveBtn.getStyleClass().add("btn-primary");

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));
        grid.setMinWidth(460);

        // Style fields
        nameField.getStyleClass().add("form-field");
        urlField.getStyleClass().add("form-field");
        tagsField.getStyleClass().add("form-field");
        nameField.setPromptText("e.g. Production API");
        urlField.setPromptText("https://example.com/health");
        tagsField.setPromptText("comma-separated tags");
        enabledCheck.setSelected(true);

        intervalSpinner.setEditable(true);
        intervalSpinner.setPrefWidth(120);
        statusCodeSpinner.setEditable(true);
        statusCodeSpinner.setPrefWidth(120);
        timeoutSpinner.setEditable(true);
        timeoutSpinner.setPrefWidth(120);

        GridPane.setHgrow(nameField, Priority.ALWAYS);
        GridPane.setHgrow(urlField, Priority.ALWAYS);

        int row = 0;
        grid.add(formLabel("Display Name *"), 0, row);
        grid.add(nameField, 1, row++);
        grid.add(formLabel("URL *"), 0, row);
        grid.add(urlField, 1, row++);
        grid.add(formLabel("Check Interval (s)"), 0, row);
        grid.add(intervalSpinner, 1, row++);
        grid.add(formLabel("Expected Status Code"), 0, row);
        grid.add(statusCodeSpinner, 1, row++);
        grid.add(formLabel("Timeout (s)"), 0, row);
        grid.add(timeoutSpinner, 1, row++);
        grid.add(formLabel("Tags"), 0, row);
        grid.add(tagsField, 1, row++);
        grid.add(enabledCheck, 1, row);

        // Pre-fill if editing
        if (existing != null) {
            nameField.setText(existing.getName());
            urlField.setText(existing.getUrl());
            intervalSpinner.getValueFactory().setValue(existing.getCheckIntervalSeconds());
            statusCodeSpinner.getValueFactory().setValue(existing.getExpectedStatusCode());
            timeoutSpinner.getValueFactory().setValue(existing.getTimeoutSeconds());
            if (existing.getTags() != null) tagsField.setText(existing.getTags());
            enabledCheck.setSelected(existing.isEnabled());
        }

        getDialogPane().setContent(grid);

        // Validate before allowing save
        saveBtn.setDisable(true);
        nameField.textProperty().addListener((o, ov, nv) -> validateForm(saveBtn));
        urlField.textProperty().addListener((o, ov, nv) -> validateForm(saveBtn));

        setResultConverter(buttonType -> {
            if (buttonType == saveButton) {
                MonitoredEndpoint ep = existing != null ? existing : MonitoredEndpoint.builder().build();
                ep.setName(nameField.getText().trim());
                ep.setUrl(urlField.getText().trim());
                ep.setCheckIntervalSeconds(intervalSpinner.getValue());
                ep.setExpectedStatusCode(statusCodeSpinner.getValue());
                ep.setTimeoutSeconds(timeoutSpinner.getValue());
                ep.setTags(tagsField.getText().trim());
                ep.setEnabled(enabledCheck.isSelected());
                if (ep.getCreatedAt() == null) {
                    ep.setCreatedAt(java.time.LocalDateTime.now());
                }
                return ep;
            }
            return null;
        });
    }

    private void validateForm(Button saveBtn) {
        boolean valid = !nameField.getText().isBlank() && !urlField.getText().isBlank()
                && urlField.getText().startsWith("http");
        saveBtn.setDisable(!valid);
    }

    private Label formLabel(String text) {
        Label lbl = new Label(text);
        lbl.getStyleClass().add("form-label");
        lbl.setMinWidth(160);
        return lbl;
    }

    public static Optional<MonitoredEndpoint> showAdd() {
        return new EndpointFormDialog(null).showAndWait();
    }

    public static Optional<MonitoredEndpoint> showEdit(MonitoredEndpoint existing) {
        return new EndpointFormDialog(existing).showAndWait();
    }
}
