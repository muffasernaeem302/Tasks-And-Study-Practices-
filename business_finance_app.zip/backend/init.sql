-- Business Finance Manager — Direct SQL Setup
-- Run with: psql -U postgres -d business_finance_db -f init.sql
-- Or paste into Supabase SQL editor

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Users ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── Companies ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS companies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    parent_company_id UUID REFERENCES companies(id) ON DELETE SET NULL,
    contact_info TEXT,
    opening_balance NUMERIC(15,2) DEFAULT 0.00,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_companies_name ON companies(name);

-- ── Materials ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    type TEXT,
    unit TEXT NOT NULL,
    unit_price NUMERIC(15,2) NOT NULL,
    stock_quantity NUMERIC(15,3) NOT NULL DEFAULT 0.000,
    low_stock_threshold NUMERIC(15,3),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_materials_name ON materials(name);

-- ── Invoices ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    status TEXT NOT NULL DEFAULT 'draft',   -- draft/confirmed/paid/unpaid
    issue_date DATE DEFAULT CURRENT_DATE,
    due_date DATE,
    total_amount NUMERIC(15,2) NOT NULL DEFAULT 0.00,
    pdf_path TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS ix_invoices_company_id ON invoices(company_id);

-- ── Transactions ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type TEXT NOT NULL,  -- purchase/sale_material/sale_product/material_used
    company_id UUID REFERENCES companies(id),
    material_id UUID NOT NULL REFERENCES materials(id),
    quantity NUMERIC(15,3) NOT NULL,
    unit_price NUMERIC(15,2) NOT NULL,
    total_amount NUMERIC(15,2) NOT NULL,
    payment_status TEXT NOT NULL DEFAULT 'unpaid',  -- paid/unpaid/partial
    amount_paid NUMERIC(15,2) DEFAULT 0.00,
    date_time TIMESTAMPTZ DEFAULT NOW(),
    notes TEXT,
    invoice_id UUID REFERENCES invoices(id)
);

CREATE INDEX IF NOT EXISTS ix_transactions_company_id ON transactions(company_id);
CREATE INDEX IF NOT EXISTS ix_transactions_date_time ON transactions(date_time);
CREATE INDEX IF NOT EXISTS ix_transactions_material_id ON transactions(material_id);

-- ── Payments ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    amount NUMERIC(15,2) NOT NULL,
    date_time TIMESTAMPTZ DEFAULT NOW(),
    notes TEXT
);

-- ── Expenses ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category TEXT NOT NULL,
    description TEXT,
    amount NUMERIC(15,2) NOT NULL,
    date_time TIMESTAMPTZ DEFAULT NOW()
);

-- ── Invoice Items ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoice_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    material_id UUID NOT NULL REFERENCES materials(id),
    quantity NUMERIC(15,3) NOT NULL,
    unit_price NUMERIC(15,2) NOT NULL,
    line_total NUMERIC(15,2) NOT NULL
);

-- ── Seed: default admin user (password: admin123) ─────────────────────────
-- Password hash generated with bcrypt. Change immediately after first login!
INSERT INTO users (username, password_hash)
VALUES ('admin', '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW')
ON CONFLICT (username) DO NOTHING;

SELECT 'Database initialized successfully.' AS status;
