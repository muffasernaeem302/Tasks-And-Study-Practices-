from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import uuid
from decimal import Decimal

from app.db.database import get_db
from app.models.invoice import Invoice, InvoiceItem
from app.models.transaction import Transaction
from app.models.material import Material
from app.models.company import Company
from app.models.user import User
from app.core.security import get_current_user
from app.schemas.invoice import InvoiceCreate, InvoiceUpdate, InvoiceOut
from app.services.pdf_service import generate_invoice_pdf

router = APIRouter(prefix="/invoices", tags=["Invoices"])

STOCK_DECREASING = {"sale_material", "sale_product"}


def enrich(invoice: Invoice) -> InvoiceOut:
    out = InvoiceOut.from_orm(invoice)
    out.created_at = invoice.created_at
    if invoice.company:
        out.company_name = invoice.company.name
    for item_out, item in zip(out.items, invoice.items):
        if item.material:
            item_out.material_name = item.material.name
    return out


@router.post("/", response_model=InvoiceOut, status_code=201)
def create_invoice(
    data: InvoiceCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    company = db.query(Company).filter(Company.id == data.company_id).first()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    # Calculate total
    total = Decimal("0")
    inv_items = []
    for item in data.items:
        material = db.query(Material).filter(Material.id == item.material_id).first()
        if not material:
            raise HTTPException(status_code=404, detail=f"Material {item.material_id} not found")
        line_total = Decimal(str(item.quantity)) * Decimal(str(item.unit_price))
        total += line_total
        inv_items.append(InvoiceItem(
            material_id=item.material_id,
            quantity=item.quantity,
            unit_price=item.unit_price,
            line_total=line_total,
        ))

    invoice = Invoice(
        company_id=data.company_id,
        status="draft",
        due_date=data.due_date,
        total_amount=total,
    )
    db.add(invoice)
    db.flush()  # get the id

    for item in inv_items:
        item.invoice_id = invoice.id
        db.add(item)

    db.commit()
    db.refresh(invoice)
    return enrich(invoice)


@router.get("/", response_model=List[InvoiceOut])
def list_invoices(
    status: Optional[str] = None,
    company_id: Optional[uuid.UUID] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    q = db.query(Invoice)
    if status:
        q = q.filter(Invoice.status == status)
    if company_id:
        q = q.filter(Invoice.company_id == company_id)
    return [enrich(inv) for inv in q.order_by(Invoice.created_at.desc()).all()]


@router.get("/{invoice_id}", response_model=InvoiceOut)
def get_invoice(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return enrich(inv)


@router.put("/{invoice_id}", response_model=InvoiceOut)
def update_invoice(
    invoice_id: uuid.UUID,
    data: InvoiceUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    for field, value in data.dict(exclude_unset=True).items():
        setattr(inv, field, value)
    db.commit()
    db.refresh(inv)
    return enrich(inv)


@router.post("/{invoice_id}/confirm", response_model=InvoiceOut)
def confirm_invoice(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Convert a draft invoice into real transactions and deduct inventory."""
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if inv.status != "draft":
        raise HTTPException(status_code=400, detail="Only draft invoices can be confirmed")

    for item in inv.items:
        material = db.query(Material).filter(Material.id == item.material_id).first()
        # Create a transaction for each line item
        txn = Transaction(
            type="sale_product",
            company_id=inv.company_id,
            material_id=item.material_id,
            quantity=item.quantity,
            unit_price=item.unit_price,
            total_amount=item.line_total,
            payment_status="unpaid",
            amount_paid=Decimal("0.00"),
            date_time=datetime.utcnow(),
            invoice_id=inv.id,
        )
        db.add(txn)
        # Deduct inventory
        if material:
            material.stock_quantity = Decimal(str(material.stock_quantity)) - Decimal(str(item.quantity))

    inv.status = "confirmed"
    db.commit()
    db.refresh(inv)
    return enrich(inv)


@router.post("/{invoice_id}/generate-pdf")
def generate_pdf(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")

    items_data = []
    for item in inv.items:
        items_data.append({
            "name": item.material.name if item.material else str(item.material_id),
            "unit": item.material.unit if item.material else "",
            "qty": item.quantity,
            "unit_price": item.unit_price,
            "line_total": item.line_total,
        })

    pdf_path = generate_invoice_pdf(
        invoice_id=str(inv.id),
        invoice_number=str(inv.id)[:8].upper(),
        company_name=inv.company.name if inv.company else "",
        company_contact=inv.company.contact_info if inv.company else "",
        issue_date=inv.issue_date,
        due_date=inv.due_date,
        items=items_data,
        total_amount=inv.total_amount,
    )
    inv.pdf_path = pdf_path
    db.commit()
    return {"pdf_path": pdf_path, "message": "PDF generated successfully"}


@router.get("/{invoice_id}/download-pdf")
def download_pdf(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv or not inv.pdf_path:
        raise HTTPException(status_code=404, detail="PDF not found. Generate it first.")
    return FileResponse(
        inv.pdf_path,
        media_type="application/pdf",
        filename=f"invoice_{str(inv.id)[:8].upper()}.pdf"
    )


@router.delete("/{invoice_id}", status_code=204)
def delete_invoice(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    inv = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if inv.status == "confirmed":
        raise HTTPException(status_code=400, detail="Cannot delete a confirmed invoice")
    db.delete(inv)
    db.commit()
