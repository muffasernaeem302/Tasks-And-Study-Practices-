from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
import uuid
from decimal import Decimal

from app.db.database import get_db
from app.models.payment import Payment
from app.models.transaction import Transaction
from app.models.user import User
from app.core.security import get_current_user
from app.schemas.payment import PaymentCreate, PaymentOut

router = APIRouter(prefix="/payments", tags=["Payments"])


@router.post("/", response_model=PaymentOut, status_code=201)
def add_payment(
    data: PaymentCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    txn = db.query(Transaction).filter(Transaction.id == data.transaction_id).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")

    payment = Payment(
        transaction_id=data.transaction_id,
        amount=data.amount,
        date_time=data.date_time or datetime.utcnow(),
        notes=data.notes,
    )
    db.add(payment)

    # Update transaction's amount_paid and payment_status
    new_paid = Decimal(str(txn.amount_paid or 0)) + Decimal(str(data.amount))
    txn.amount_paid = new_paid
    total = Decimal(str(txn.total_amount))
    if new_paid >= total:
        txn.payment_status = "paid"
    elif new_paid > 0:
        txn.payment_status = "partial"

    db.commit()
    db.refresh(payment)
    return payment


@router.get("/transaction/{transaction_id}", response_model=List[PaymentOut])
def list_payments_for_transaction(
    transaction_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return db.query(Payment).filter(Payment.transaction_id == transaction_id).all()
