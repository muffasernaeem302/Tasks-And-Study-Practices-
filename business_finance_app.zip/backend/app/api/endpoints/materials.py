from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import uuid
from decimal import Decimal

from app.db.database import get_db
from app.models.material import Material
from app.models.user import User
from app.core.security import get_current_user
from app.schemas.material import MaterialCreate, MaterialUpdate, MaterialOut

router = APIRouter(prefix="/materials", tags=["Materials"])


def to_out(m: Material) -> MaterialOut:
    out = MaterialOut.from_orm(m)
    out.created_at = m.created_at.isoformat()
    if m.low_stock_threshold is not None:
        out.is_low_stock = Decimal(str(m.stock_quantity)) < Decimal(str(m.low_stock_threshold))
    return out


@router.get("/", response_model=List[MaterialOut])
def list_materials(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return [to_out(m) for m in db.query(Material).all()]


@router.post("/", response_model=MaterialOut, status_code=201)
def create_material(
    data: MaterialCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    material = Material(**data.dict())
    db.add(material)
    db.commit()
    db.refresh(material)
    return to_out(material)


@router.get("/{material_id}", response_model=MaterialOut)
def get_material(
    material_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    m = db.query(Material).filter(Material.id == material_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Material not found")
    return to_out(m)


@router.put("/{material_id}", response_model=MaterialOut)
def update_material(
    material_id: uuid.UUID,
    data: MaterialUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    m = db.query(Material).filter(Material.id == material_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Material not found")
    for field, value in data.dict(exclude_unset=True).items():
        setattr(m, field, value)
    db.commit()
    db.refresh(m)
    return to_out(m)


@router.delete("/{material_id}", status_code=204)
def delete_material(
    material_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    m = db.query(Material).filter(Material.id == material_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Material not found")
    db.delete(m)
    db.commit()


@router.get("/low-stock/alerts", response_model=List[MaterialOut])
def low_stock_alerts(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    materials = db.query(Material).filter(Material.low_stock_threshold != None).all()
    return [to_out(m) for m in materials if
            Decimal(str(m.stock_quantity)) < Decimal(str(m.low_stock_threshold))]
