from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import uuid
from decimal import Decimal

from app.db.database import get_db
from app.models.transaction import Transaction
from app.models.material import Material
from app.models.company import Company
from app.models.user import User
from app.core.security import get_current_user
from app.schemas.transaction import TransactionCreate, TransactionUpdate, TransactionOut, LedgerEntry

router = APIRouter(prefix="/transactions", tags=["Transactions"])

STOCK_INCREASING = {"purchase"}
STOCK_DECREASING = {"sale_material", "sale_product", "material_used"}


def apply_inventory(material: Material, txn_type: str, quantity: Decimal):
    qty = Decimal(str(quantity))
    if txn_type in STOCK_INCREASING:
        material.stock_quantity = Decimal(str(material.stock_quantity)) + qty
    elif txn_type in STOCK_DECREASING:
        material.stock_quantity = Decimal(str(material.stock_quantity)) - qty


def to_out(t: Transaction, db: Session) -> TransactionOut:
    out = TransactionOut.from_orm(t)
    if t.material:
        out.material_name = t.material.name
    if t.company:
        out.company_name = t.company.name
    return out


@router.post("/", response_model=TransactionOut, status_code=201)
def create_transaction(
    data: TransactionCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    material = db.query(Material).filter(Material.id == data.material_id).first()
    if not material:
        raise HTTPException(status_code=404, detail="Material not found")

    # Auto-calculate price/amount
    unit_price = data.unit_price if data.unit_price else Decimal(str(material.unit_price))
    quantity = Decimal(str(data.quantity))
    total_amount = data.total_amount if data.total_amount else unit_price * quantity

    # Server-side re-validation
    computed_total = unit_price * quantity
    if abs(computed_total - total_amount) > Decimal("0.05"):
        total_amount = computed_total  # trust server math

    # Payment status logic
    amount_paid = Decimal(str(data.amount_paid or 0))
    if amount_paid >= total_amount:
        payment_status = "paid"
    elif amount_paid > 0:
        payment_status = "partial"
    else:
        payment_status = data.payment_status

    txn = Transaction(
        type=data.type,
        company_id=data.company_id,
        material_id=data.material_id,
        quantity=quantity,
        unit_price=unit_price,
        total_amount=total_amount,
        payment_status=payment_status,
        amount_paid=amount_paid,
        date_time=data.date_time or datetime.utcnow(),
        notes=data.notes,
        invoice_id=data.invoice_id,
    )
    db.add(txn)

    # Inventory update
    apply_inventory(material, data.type, quantity)
    db.commit()
    db.refresh(txn)
    return to_out(txn, db)


@router.get("/", response_model=List[TransactionOut])
def list_transactions(
    company_id: Optional[uuid.UUID] = None,
    material_id: Optional[uuid.UUID] = None,
    type: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    q = db.query(Transaction)
    if company_id:
        q = q.filter(Transaction.company_id == company_id)
    if material_id:
        q = q.filter(Transaction.material_id == material_id)
    if type:
        q = q.filter(Transaction.type == type)
    return [to_out(t, db) for t in q.order_by(Transaction.date_time.desc()).all()]


@router.get("/ledger/{company_id}", response_model=List[LedgerEntry])
def get_ledger(
    company_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    company = db.query(Company).filter(Company.id == company_id).first()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    txns = (db.query(Transaction)
            .filter(Transaction.company_id == company_id)
            .order_by(Transaction.date_time.asc())
            .all())

    running_balance = Decimal(str(company.opening_balance or 0))
    entries = []
    for t in txns:
        total = Decimal(str(t.total_amount))
        paid = Decimal(str(t.amount_paid or 0))
        due = total - paid

        if t.type in ("sale_material", "sale_product"):
            running_balance += due
        elif t.type == "purchase":
            running_balance -= due

        entries.append(LedgerEntry(
            transaction_id=t.id,
            date_time=t.date_time,
            type=t.type,
            material_name=t.material.name if t.material else "",
            quantity=t.quantity,
            unit_price=t.unit_price,
            total_amount=total,
            payment_status=t.payment_status,
            amount_paid=paid,
            amount_due=due,
            running_balance=running_balance,
            notes=t.notes,
        ))
    return entries


@router.put("/{transaction_id}", response_model=TransactionOut)
def update_transaction(
    transaction_id: uuid.UUID,
    data: TransactionUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    for field, value in data.dict(exclude_unset=True).items():
        setattr(txn, field, value)
    db.commit()
    db.refresh(txn)
    return to_out(txn, db)


@router.get("/{transaction_id}", response_model=TransactionOut)
def get_transaction(
    transaction_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    txn = db.query(Transaction).filter(Transaction.id == transaction_id).first()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return to_out(txn, db)
