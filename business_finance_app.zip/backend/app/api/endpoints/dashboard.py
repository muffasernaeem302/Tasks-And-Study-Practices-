from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from decimal import Decimal

from app.db.database import get_db
from app.models.transaction import Transaction
from app.models.invoice import Invoice
from app.models.material import Material
from app.models.expense import Expense
from app.models.user import User
from app.core.security import get_current_user

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/summary")
def get_summary(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    # Total receivable: unpaid/partial sale transactions
    sale_txns = db.query(Transaction).filter(
        Transaction.type.in_(["sale_material", "sale_product"]),
        Transaction.payment_status.in_(["unpaid", "partial"])
    ).all()
    total_receivable = sum(
        Decimal(str(t.total_amount)) - Decimal(str(t.amount_paid or 0))
        for t in sale_txns
    )

    # Total payable: unpaid/partial purchase transactions
    purchase_txns = db.query(Transaction).filter(
        Transaction.type == "purchase",
        Transaction.payment_status.in_(["unpaid", "partial"])
    ).all()
    total_payable = sum(
        Decimal(str(t.total_amount)) - Decimal(str(t.amount_paid or 0))
        for t in purchase_txns
    )

    # Low stock alerts
    materials = db.query(Material).filter(Material.low_stock_threshold != None).all()
    low_stock = [
        {"id": str(m.id), "name": m.name, "stock": float(m.stock_quantity),
         "threshold": float(m.low_stock_threshold), "unit": m.unit}
        for m in materials
        if Decimal(str(m.stock_quantity)) < Decimal(str(m.low_stock_threshold))
    ]

    # Unpaid invoices
    unpaid_invoices = db.query(Invoice).filter(
        Invoice.status.in_(["confirmed", "unpaid"])
    ).count()

    # Draft invoices
    draft_invoices = db.query(Invoice).filter(Invoice.status == "draft").count()

    return {
        "total_receivable": float(total_receivable),
        "total_payable": float(total_payable),
        "low_stock_count": len(low_stock),
        "low_stock_items": low_stock,
        "unpaid_invoices": unpaid_invoices,
        "draft_invoices": draft_invoices,
    }


@router.get("/notifications")
def get_notifications(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    notifications = []

    # Low stock
    materials = db.query(Material).filter(Material.low_stock_threshold != None).all()
    for m in materials:
        if Decimal(str(m.stock_quantity)) < Decimal(str(m.low_stock_threshold)):
            notifications.append({
                "type": "low_stock",
                "severity": "warning",
                "message": f"Low stock: {m.name} — {float(m.stock_quantity)} {m.unit} remaining",
                "entity_id": str(m.id),
            })

    # Unpaid invoices
    unpaid = db.query(Invoice).filter(Invoice.status.in_(["confirmed", "unpaid"])).all()
    for inv in unpaid:
        notifications.append({
            "type": "unpaid_invoice",
            "severity": "info",
            "message": f"Unpaid invoice #{str(inv.id)[:8].upper()} — {float(inv.total_amount):,.2f}",
            "entity_id": str(inv.id),
        })

    return {"notifications": notifications, "count": len(notifications)}
