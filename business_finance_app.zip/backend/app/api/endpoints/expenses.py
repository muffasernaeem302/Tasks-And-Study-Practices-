from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, extract
from typing import List, Optional
from datetime import datetime
import uuid

from app.db.database import get_db
from app.models.expense import Expense
from app.models.user import User
from app.core.security import get_current_user
from app.schemas.expense import ExpenseCreate, ExpenseUpdate, ExpenseOut

router = APIRouter(prefix="/expenses", tags=["Expenses"])


@router.get("/", response_model=List[ExpenseOut])
def list_expenses(
    year: Optional[int] = None,
    month: Optional[int] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    q = db.query(Expense)
    if year:
        q = q.filter(extract("year", Expense.date_time) == year)
    if month:
        q = q.filter(extract("month", Expense.date_time) == month)
    if category:
        q = q.filter(Expense.category == category)
    return q.order_by(Expense.date_time.desc()).all()


@router.post("/", response_model=ExpenseOut, status_code=201)
def create_expense(
    data: ExpenseCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    expense = Expense(
        category=data.category,
        description=data.description,
        amount=data.amount,
        date_time=data.date_time or datetime.utcnow(),
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    return expense


@router.get("/summary")
def expense_summary(
    year: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    monthly = (
        db.query(
            extract("month", Expense.date_time).label("month"),
            func.sum(Expense.amount).label("total")
        )
        .filter(extract("year", Expense.date_time) == year)
        .group_by("month")
        .all()
    )
    yearly_total = (
        db.query(func.sum(Expense.amount))
        .filter(extract("year", Expense.date_time) == year)
        .scalar() or 0
    )
    return {
        "year": year,
        "yearly_total": float(yearly_total),
        "monthly_breakdown": [{"month": int(r.month), "total": float(r.total)} for r in monthly]
    }


@router.put("/{expense_id}", response_model=ExpenseOut)
def update_expense(
    expense_id: uuid.UUID,
    data: ExpenseUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    expense = db.query(Expense).filter(Expense.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    for field, value in data.dict(exclude_unset=True).items():
        setattr(expense, field, value)
    db.commit()
    db.refresh(expense)
    return expense


@router.delete("/{expense_id}", status_code=204)
def delete_expense(
    expense_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    expense = db.query(Expense).filter(Expense.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    db.delete(expense)
    db.commit()
