from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import uuid
from decimal import Decimal

from app.db.database import get_db
from app.models.company import Company
from app.models.transaction import Transaction
from app.models.user import User
from app.core.security import get_current_user
from app.schemas.company import CompanyCreate, CompanyUpdate, CompanyOut, CompanyWithSubs

router = APIRouter(prefix="/companies", tags=["Companies"])


def compute_balance(company: Company, db: Session) -> Decimal:
    """Compute current balance: opening_balance + sum of unpaid/partial amounts due."""
    opening = Decimal(str(company.opening_balance or 0))
    txns = db.query(Transaction).filter(Transaction.company_id == company.id).all()
    total_due = Decimal("0")
    for t in txns:
        due = Decimal(str(t.total_amount)) - Decimal(str(t.amount_paid or 0))
        # Sales = they owe you (positive), Purchases = you owe them (negative)
        if t.type in ("sale_material", "sale_product"):
            total_due += due
        elif t.type == "purchase":
            total_due -= due
    return opening + total_due


@router.get("/", response_model=List[CompanyWithSubs])
def list_companies(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    companies = db.query(Company).filter(Company.parent_company_id == None).all()
    result = []
    for c in companies:
        c_out = CompanyWithSubs.from_orm(c)
        c_out.current_balance = compute_balance(c, db)
        c_out.created_at = c.created_at.isoformat() if c.created_at else ""
        result.append(c_out)
    return result


@router.post("/", response_model=CompanyOut, status_code=201)
def create_company(
    data: CompanyCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    company = Company(**data.dict())
    db.add(company)
    db.commit()
    db.refresh(company)
    out = CompanyOut.from_orm(company)
    out.created_at = company.created_at.isoformat()
    return out


@router.get("/{company_id}", response_model=CompanyWithSubs)
def get_company(
    company_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    company = db.query(Company).filter(Company.id == company_id).first()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    out = CompanyWithSubs.from_orm(company)
    out.current_balance = compute_balance(company, db)
    out.created_at = company.created_at.isoformat()
    return out


@router.put("/{company_id}", response_model=CompanyOut)
def update_company(
    company_id: uuid.UUID,
    data: CompanyUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    company = db.query(Company).filter(Company.id == company_id).first()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    for field, value in data.dict(exclude_unset=True).items():
        setattr(company, field, value)
    db.commit()
    db.refresh(company)
    out = CompanyOut.from_orm(company)
    out.created_at = company.created_at.isoformat()
    return out


@router.delete("/{company_id}", status_code=204)
def delete_company(
    company_id: uuid.UUID,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    company = db.query(Company).filter(Company.id == company_id).first()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    db.delete(company)
    db.commit()
