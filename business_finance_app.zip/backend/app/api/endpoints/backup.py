"""Backup and data export endpoints."""
import csv
import io
import os
import subprocess
from datetime import datetime

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse, FileResponse
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.models.transaction import Transaction
from app.models.expense import Expense
from app.models.company import Company
from app.models.material import Material
from app.models.user import User
from app.core.config import settings
from app.core.security import get_current_user

router = APIRouter(prefix="/backup", tags=["Backup & Export"])


def _write_csv(headers: list, rows: list) -> io.StringIO:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(headers)
    writer.writerows(rows)
    buf.seek(0)
    return buf


@router.get("/export/transactions")
def export_transactions(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    txns = db.query(Transaction).order_by(Transaction.date_time).all()
    headers = ["id", "type", "company", "material", "quantity", "unit_price",
               "total_amount", "payment_status", "amount_paid", "date_time", "notes"]
    rows = [
        [str(t.id), t.type,
         t.company.name if t.company else "",
         t.material.name if t.material else "",
         float(t.quantity), float(t.unit_price), float(t.total_amount),
         t.payment_status, float(t.amount_paid or 0),
         t.date_time.isoformat(), t.notes or ""]
        for t in txns
    ]
    buf = _write_csv(headers, rows)
    return StreamingResponse(
        buf,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=transactions.csv"}
    )


@router.get("/export/expenses")
def export_expenses(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    expenses = db.query(Expense).order_by(Expense.date_time).all()
    headers = ["id", "category", "description", "amount", "date_time"]
    rows = [
        [str(e.id), e.category, e.description or "",
         float(e.amount), e.date_time.isoformat()]
        for e in expenses
    ]
    buf = _write_csv(headers, rows)
    return StreamingResponse(
        buf,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=expenses.csv"}
    )


@router.get("/export/companies")
def export_companies(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    companies = db.query(Company).order_by(Company.name).all()
    headers = ["id", "name", "parent_company_id", "contact_info", "opening_balance"]
    rows = [
        [str(c.id), c.name,
         str(c.parent_company_id) if c.parent_company_id else "",
         c.contact_info or "", float(c.opening_balance or 0)]
        for c in companies
    ]
    buf = _write_csv(headers, rows)
    return StreamingResponse(
        buf,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=companies.csv"}
    )


@router.get("/export/materials")
def export_materials(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    materials = db.query(Material).order_by(Material.name).all()
    headers = ["id", "name", "type", "unit", "unit_price", "stock_quantity", "low_stock_threshold"]
    rows = [
        [str(m.id), m.name, m.type or "", m.unit,
         float(m.unit_price), float(m.stock_quantity),
         float(m.low_stock_threshold) if m.low_stock_threshold else ""]
        for m in materials
    ]
    buf = _write_csv(headers, rows)
    return StreamingResponse(
        buf,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=materials.csv"}
    )


@router.post("/database")
def backup_database(_: User = Depends(get_current_user)):
    """Run pg_dump and return the .sql backup file."""
    os.makedirs(settings.BACKUP_DIR, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"backup_{timestamp}.sql"
    filepath = os.path.join(settings.BACKUP_DIR, filename)

    db_url = settings.DATABASE_URL
    # Parse connection string for pg_dump
    try:
        result = subprocess.run(
            ["pg_dump", db_url, "-f", filepath],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            return {"error": result.stderr, "message": "Backup failed"}
    except FileNotFoundError:
        return {"error": "pg_dump not found", "message": "Install PostgreSQL client tools"}
    except subprocess.TimeoutExpired:
        return {"error": "Timeout", "message": "Database backup timed out"}

    return {"filename": filename, "message": "Backup created successfully"}


@router.get("/database/{filename}")
def download_backup(filename: str, _: User = Depends(get_current_user)):
    filepath = os.path.join(settings.BACKUP_DIR, filename)
    if not os.path.exists(filepath) or not filename.endswith(".sql"):
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Backup file not found")
    return FileResponse(filepath, filename=filename, media_type="application/octet-stream")
