from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "postgresql://user:password@localhost:5432/business_finance_db"

    # JWT
    SECRET_KEY: str = "change-this-secret-key-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 24 hours

    # App
    APP_NAME: str = "Business Finance Manager"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # File Storage
    INVOICE_PDF_DIR: str = "./generated_invoices"
    BACKUP_DIR: str = "./backups"

    # Company Profile
    COMPANY_NAME: str = "Your Company Name"
    COMPANY_ADDRESS: str = "Your Address"
    COMPANY_PHONE: str = "+1234567890"
    COMPANY_EMAIL: str = "info@yourcompany.com"

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()

# Ensure directories exist
os.makedirs(settings.INVOICE_PDF_DIR, exist_ok=True)
os.makedirs(settings.BACKUP_DIR, exist_ok=True)
