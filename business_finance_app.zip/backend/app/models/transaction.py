import uuid
from sqlalchemy import Column, String, DateTime, Numeric, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    type = Column(String, nullable=False)  # purchase / sale_material / sale_product / material_used
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=True)
    material_id = Column(UUID(as_uuid=True), ForeignKey("materials.id"), nullable=False)
    quantity = Column(Numeric(15, 3), nullable=False)
    unit_price = Column(Numeric(15, 2), nullable=False)
    total_amount = Column(Numeric(15, 2), nullable=False)
    payment_status = Column(String, nullable=False, default="unpaid")  # paid / unpaid / partial
    amount_paid = Column(Numeric(15, 2), default=0.00)
    date_time = Column(DateTime(timezone=True), server_default=func.now())
    notes = Column(Text, nullable=True)
    invoice_id = Column(UUID(as_uuid=True), ForeignKey("invoices.id"), nullable=True)

    # Relationships
    company = relationship("Company", back_populates="transactions")
    material = relationship("Material", back_populates="transactions")
    payments = relationship("Payment", back_populates="transaction", cascade="all, delete-orphan")
    invoice = relationship("Invoice", back_populates="transactions")
