import uuid
from sqlalchemy import Column, String, DateTime, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.db.database import Base


class Expense(Base):
    __tablename__ = "expenses"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    category = Column(String, nullable=False)  # rent, transport, utilities, etc.
    description = Column(Text, nullable=True)
    amount = Column(Numeric(15, 2), nullable=False)
    date_time = Column(DateTime(timezone=True), server_default=func.now())
