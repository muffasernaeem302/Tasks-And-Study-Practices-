import uuid
from sqlalchemy import Column, String, DateTime, Numeric
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base


class Material(Base):
    __tablename__ = "materials"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False, index=True)
    type = Column(String, nullable=True)           # raw material / product / etc.
    unit = Column(String, nullable=False)           # kg, liter, piece, etc.
    unit_price = Column(Numeric(15, 2), nullable=False, default=0.00)
    stock_quantity = Column(Numeric(15, 3), nullable=False, default=0.000)
    low_stock_threshold = Column(Numeric(15, 3), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    transactions = relationship("Transaction", back_populates="material")
    invoice_items = relationship("InvoiceItem", back_populates="material")
