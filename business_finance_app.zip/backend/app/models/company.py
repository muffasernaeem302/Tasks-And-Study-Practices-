import uuid
from sqlalchemy import Column, String, DateTime, Numeric, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base


class Company(Base):
    __tablename__ = "companies"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False, index=True)
    parent_company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=True)
    contact_info = Column(String, nullable=True)
    opening_balance = Column(Numeric(15, 2), default=0.00)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    sub_companies = relationship("Company", backref="parent_company",
                                 foreign_keys=[parent_company_id])
    transactions = relationship("Transaction", back_populates="company")
    invoices = relationship("Invoice", back_populates="company")
