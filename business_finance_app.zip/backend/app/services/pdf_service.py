"""Invoice PDF generation using ReportLab."""
import os
from datetime import date
from decimal import Decimal
from typing import List

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER, TA_LEFT

from app.core.config import settings


def generate_invoice_pdf(
    invoice_id: str,
    invoice_number: str,
    company_name: str,
    company_contact: str,
    issue_date: date,
    due_date: date | None,
    items: List[dict],  # [{name, qty, unit, unit_price, line_total}]
    total_amount: Decimal,
) -> str:
    """Generate invoice PDF and return the file path."""
    os.makedirs(settings.INVOICE_PDF_DIR, exist_ok=True)
    filepath = os.path.join(settings.INVOICE_PDF_DIR, f"invoice_{invoice_id}.pdf")

    doc = SimpleDocTemplate(
        filepath, pagesize=A4,
        rightMargin=20 * mm, leftMargin=20 * mm,
        topMargin=20 * mm, bottomMargin=20 * mm
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("title", parent=styles["Heading1"],
                                 fontSize=20, textColor=colors.HexColor("#1a3c5e"))
    header_style = ParagraphStyle("header", parent=styles["Normal"],
                                  fontSize=10, textColor=colors.grey)
    normal = styles["Normal"]

    story = []

    # ── Letterhead ──────────────────────────────────────────────────────────
    story.append(Paragraph(settings.COMPANY_NAME, title_style))
    story.append(Paragraph(settings.COMPANY_ADDRESS, header_style))
    story.append(Paragraph(
        f"Phone: {settings.COMPANY_PHONE}  |  Email: {settings.COMPANY_EMAIL}",
        header_style
    ))
    story.append(Spacer(1, 8 * mm))

    # ── Invoice metadata ─────────────────────────────────────────────────────
    meta_data = [
        ["INVOICE", f"#{invoice_number}"],
        ["Bill To:", company_name],
        ["Contact:", company_contact or "—"],
        ["Issue Date:", issue_date.strftime("%d %b %Y")],
        ["Due Date:", due_date.strftime("%d %b %Y") if due_date else "On Receipt"],
    ]
    meta_table = Table(meta_data, colWidths=[40 * mm, 120 * mm])
    meta_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("TEXTCOLOR", (0, 0), (0, 0), colors.HexColor("#1a3c5e")),
        ("FONTSIZE", (0, 0), (0, 0), 14),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 8 * mm))

    # ── Line items table ─────────────────────────────────────────────────────
    header_row = ["#", "Item / Material", "Unit", "Qty", "Unit Price", "Total"]
    rows = [header_row]
    for idx, item in enumerate(items, 1):
        rows.append([
            str(idx),
            item["name"],
            item.get("unit", ""),
            str(item["qty"]),
            f"{float(item['unit_price']):,.2f}",
            f"{float(item['line_total']):,.2f}",
        ])

    col_widths = [10 * mm, 65 * mm, 20 * mm, 20 * mm, 30 * mm, 30 * mm]
    items_table = Table(rows, colWidths=col_widths)
    items_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c5e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (3, 0), (-1, -1), "RIGHT"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f7fa")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(items_table)
    story.append(Spacer(1, 6 * mm))

    # ── Total ────────────────────────────────────────────────────────────────
    total_table = Table(
        [["", "TOTAL DUE", f"{float(total_amount):,.2f}"]],
        colWidths=[95 * mm, 40 * mm, 40 * mm]
    )
    total_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 12),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("TEXTCOLOR", (1, 0), (-1, -1), colors.HexColor("#1a3c5e")),
        ("LINEABOVE", (1, 0), (-1, 0), 1.5, colors.HexColor("#1a3c5e")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(total_table)

    story.append(Spacer(1, 12 * mm))
    story.append(Paragraph(
        "Thank you for your business.",
        ParagraphStyle("footer", parent=normal, alignment=TA_CENTER,
                       textColor=colors.grey, fontSize=9)
    ))

    doc.build(story)
    return filepath
