from pydantic import BaseModel, validator
from typing import Optional, List
from decimal import Decimal
from datetime import datetime
import uuid


class TransactionCreate(BaseModel):
    type: str  # purchase / sale_material / sale_product / material_used
    company_id: Optional[uuid.UUID] = None
    material_id: uuid.UUID
    quantity: Decimal
    unit_price: Optional[Decimal] = None   # if not given, auto-filled from material
    total_amount: Optional[Decimal] = None  # if not given, calculated
    payment_status: str = "unpaid"          # paid / unpaid / partial
    amount_paid: Optional[Decimal] = Decimal("0.00")
    date_time: Optional[datetime] = None
    notes: Optional[str] = None
    invoice_id: Optional[uuid.UUID] = None

    @validator("type")
    def validate_type(cls, v):
        allowed = {"purchase", "sale_material", "sale_product", "material_used"}
        if v not in allowed:
            raise ValueError(f"type must be one of {allowed}")
        return v

    @validator("payment_status")
    def validate_payment_status(cls, v):
        allowed = {"paid", "unpaid", "partial"}
        if v not in allowed:
            raise ValueError(f"payment_status must be one of {allowed}")
        return v


class TransactionUpdate(BaseModel):
    payment_status: Optional[str] = None
    amount_paid: Optional[Decimal] = None
    notes: Optional[str] = None
    date_time: Optional[datetime] = None


class TransactionOut(BaseModel):
    id: uuid.UUID
    type: str
    company_id: Optional[uuid.UUID]
    material_id: uuid.UUID
    quantity: Decimal
    unit_price: Decimal
    total_amount: Decimal
    payment_status: str
    amount_paid: Decimal
    date_time: datetime
    notes: Optional[str]
    invoice_id: Optional[uuid.UUID]
    material_name: Optional[str] = None
    company_name: Optional[str] = None

    class Config:
        from_attributes = True


class LedgerEntry(BaseModel):
    transaction_id: uuid.UUID
    date_time: datetime
    type: str
    material_name: str
    quantity: Decimal
    unit_price: Decimal
    total_amount: Decimal
    payment_status: str
    amount_paid: Decimal
    amount_due: Decimal
    running_balance: Decimal
    notes: Optional[str]
