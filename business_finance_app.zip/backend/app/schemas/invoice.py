from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
from datetime import date, datetime
import uuid


class InvoiceItemCreate(BaseModel):
    material_id: uuid.UUID
    quantity: Decimal
    unit_price: Decimal


class InvoiceItemOut(BaseModel):
    id: uuid.UUID
    invoice_id: uuid.UUID
    material_id: uuid.UUID
    quantity: Decimal
    unit_price: Decimal
    line_total: Decimal
    material_name: Optional[str] = None

    class Config:
        from_attributes = True


class InvoiceCreate(BaseModel):
    company_id: uuid.UUID
    due_date: Optional[date] = None
    items: List[InvoiceItemCreate]


class InvoiceUpdate(BaseModel):
    status: Optional[str] = None
    due_date: Optional[date] = None


class InvoiceOut(BaseModel):
    id: uuid.UUID
    company_id: uuid.UUID
    status: str
    issue_date: date
    due_date: Optional[date]
    total_amount: Decimal
    pdf_path: Optional[str]
    created_at: datetime
    items: List[InvoiceItemOut] = []
    company_name: Optional[str] = None

    class Config:
        from_attributes = True
