from pydantic import BaseModel
from typing import Optional
from decimal import Decimal
import uuid


class MaterialBase(BaseModel):
    name: str
    type: Optional[str] = None
    unit: str
    unit_price: Decimal
    stock_quantity: Optional[Decimal] = Decimal("0.000")
    low_stock_threshold: Optional[Decimal] = None


class MaterialCreate(MaterialBase):
    pass


class MaterialUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    unit: Optional[str] = None
    unit_price: Optional[Decimal] = None
    stock_quantity: Optional[Decimal] = None
    low_stock_threshold: Optional[Decimal] = None


class MaterialOut(MaterialBase):
    id: uuid.UUID
    created_at: str
    is_low_stock: Optional[bool] = False

    class Config:
        from_attributes = True
