from pydantic import BaseModel
from typing import Optional
from decimal import Decimal
from datetime import datetime
import uuid


class ExpenseCreate(BaseModel):
    category: str
    description: Optional[str] = None
    amount: Decimal
    date_time: Optional[datetime] = None


class ExpenseUpdate(BaseModel):
    category: Optional[str] = None
    description: Optional[str] = None
    amount: Optional[Decimal] = None
    date_time: Optional[datetime] = None


class ExpenseOut(BaseModel):
    id: uuid.UUID
    category: str
    description: Optional[str]
    amount: Decimal
    date_time: datetime

    class Config:
        from_attributes = True
