from pydantic import BaseModel
from typing import Optional, List
from decimal import Decimal
import uuid


class CompanyBase(BaseModel):
    name: str
    parent_company_id: Optional[uuid.UUID] = None
    contact_info: Optional[str] = None
    opening_balance: Optional[Decimal] = Decimal("0.00")


class CompanyCreate(CompanyBase):
    pass


class CompanyUpdate(BaseModel):
    name: Optional[str] = None
    parent_company_id: Optional[uuid.UUID] = None
    contact_info: Optional[str] = None
    opening_balance: Optional[Decimal] = None


class CompanyOut(CompanyBase):
    id: uuid.UUID
    created_at: str

    class Config:
        from_attributes = True


class CompanyWithSubs(CompanyOut):
    sub_companies: List["CompanyOut"] = []
    current_balance: Optional[Decimal] = None

    class Config:
        from_attributes = True
