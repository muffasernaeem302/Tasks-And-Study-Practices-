from pydantic import BaseModel
from typing import Optional
from decimal import Decimal
from datetime import datetime
import uuid


class PaymentCreate(BaseModel):
    transaction_id: uuid.UUID
    amount: Decimal
    date_time: Optional[datetime] = None
    notes: Optional[str] = None


class PaymentOut(BaseModel):
    id: uuid.UUID
    transaction_id: uuid.UUID
    amount: Decimal
    date_time: datetime
    notes: Optional[str]

    class Config:
        from_attributes = True
