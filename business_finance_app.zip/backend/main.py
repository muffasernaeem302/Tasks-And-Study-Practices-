"""
Business Finance Manager — FastAPI Backend
Run with: uvicorn main:app --reload
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.db.database import Base, engine
from app.api.endpoints import auth, companies, materials, transactions, payments, expenses, invoices, dashboard, backup

# Create all tables (use Alembic in production)
import app.models  # noqa: ensure all models are imported before creating tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="REST API for Business & Finance Manager — tracks transactions, inventory, invoices, and ledgers.",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS — allow Flutter desktop/web and local dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict in production to your actual domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
prefix = "/api"
app.include_router(auth.router, prefix=prefix)
app.include_router(companies.router, prefix=prefix)
app.include_router(materials.router, prefix=prefix)
app.include_router(transactions.router, prefix=prefix)
app.include_router(payments.router, prefix=prefix)
app.include_router(expenses.router, prefix=prefix)
app.include_router(invoices.router, prefix=prefix)
app.include_router(dashboard.router, prefix=prefix)
app.include_router(backup.router, prefix=prefix)


@app.get("/")
def root():
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "health": "ok",
    }


@app.get("/health")
def health():
    return {"status": "ok"}
