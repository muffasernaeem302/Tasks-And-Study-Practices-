"""
Backend tests for Business Finance Manager.
Run with: pytest tests/ -v
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.database import Base, get_db
from main import app

# Use in-memory SQLite for tests
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
Base.metadata.create_all(bind=engine)
client = TestClient(app)


# ── Helpers ──────────────────────────────────────────────────────────────────
def get_token(username="testuser", password="testpass123"):
    client.post("/api/auth/register", json={"username": username, "password": password})
    resp = client.post("/api/auth/login", json={"username": username, "password": password})
    return resp.json()["access_token"]


def auth_headers(token):
    return {"Authorization": f"Bearer {token}"}


# ── Auth Tests ────────────────────────────────────────────────────────────────
class TestAuth:
    def test_register_success(self):
        resp = client.post("/api/auth/register",
                           json={"username": "newuser1", "password": "password123"})
        assert resp.status_code == 201
        assert "id" in resp.json()

    def test_register_duplicate(self):
        client.post("/api/auth/register",
                    json={"username": "dupuser", "password": "password123"})
        resp = client.post("/api/auth/register",
                           json={"username": "dupuser", "password": "password123"})
        assert resp.status_code == 400

    def test_login_success(self):
        client.post("/api/auth/register",
                    json={"username": "loginuser", "password": "password123"})
        resp = client.post("/api/auth/login",
                           json={"username": "loginuser", "password": "password123"})
        assert resp.status_code == 200
        assert "access_token" in resp.json()

    def test_login_wrong_password(self):
        client.post("/api/auth/register",
                    json={"username": "badpass", "password": "correct"})
        resp = client.post("/api/auth/login",
                           json={"username": "badpass", "password": "wrong"})
        assert resp.status_code == 401

    def test_me_endpoint(self):
        token = get_token("meuser", "mepass123")
        resp = client.get("/api/auth/me", headers=auth_headers(token))
        assert resp.status_code == 200
        assert resp.json()["username"] == "meuser"

    def test_protected_route_without_token(self):
        resp = client.get("/api/companies/")
        assert resp.status_code == 401


# ── Company Tests ─────────────────────────────────────────────────────────────
class TestCompanies:
    def setup_method(self):
        self.token = get_token("companytest", "pass12345")
        self.headers = auth_headers(self.token)

    def test_create_company(self):
        resp = client.post("/api/companies/",
                           json={"name": "Acme Corp", "opening_balance": 1000},
                           headers=self.headers)
        assert resp.status_code == 201
        assert resp.json()["name"] == "Acme Corp"

    def test_list_companies(self):
        client.post("/api/companies/",
                    json={"name": "List Test Co"}, headers=self.headers)
        resp = client.get("/api/companies/", headers=self.headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_create_sub_company(self):
        parent = client.post("/api/companies/",
                             json={"name": "Parent Co"}, headers=self.headers).json()
        resp = client.post("/api/companies/",
                           json={"name": "Sub Co", "parent_company_id": parent["id"]},
                           headers=self.headers)
        assert resp.status_code == 201

    def test_update_company(self):
        co = client.post("/api/companies/",
                         json={"name": "Old Name"}, headers=self.headers).json()
        resp = client.put(f"/api/companies/{co['id']}",
                          json={"name": "New Name"}, headers=self.headers)
        assert resp.status_code == 200
        assert resp.json()["name"] == "New Name"


# ── Material Tests ────────────────────────────────────────────────────────────
class TestMaterials:
    def setup_method(self):
        self.token = get_token("materialtest", "pass12345")
        self.headers = auth_headers(self.token)

    def test_create_material(self):
        resp = client.post("/api/materials/",
                           json={"name": "Steel Rod", "unit": "kg",
                                 "unit_price": 5.50, "stock_quantity": 100,
                                 "low_stock_threshold": 10},
                           headers=self.headers)
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Steel Rod"
        assert data["is_low_stock"] is False

    def test_low_stock_detection(self):
        resp = client.post("/api/materials/",
                           json={"name": "Rare Metal", "unit": "g",
                                 "unit_price": 100, "stock_quantity": 5,
                                 "low_stock_threshold": 50},
                           headers=self.headers)
        assert resp.json()["is_low_stock"] is True

    def test_low_stock_alerts_endpoint(self):
        client.post("/api/materials/",
                    json={"name": "AlertMat", "unit": "pcs",
                          "unit_price": 1, "stock_quantity": 2,
                          "low_stock_threshold": 10},
                    headers=self.headers)
        resp = client.get("/api/materials/low-stock/alerts", headers=self.headers)
        assert resp.status_code == 200
        assert len(resp.json()) >= 1


# ── Transaction Tests ─────────────────────────────────────────────────────────
class TestTransactions:
    def setup_method(self):
        self.token = get_token("txntest", "pass12345")
        self.headers = auth_headers(self.token)
        # Create a material for transactions
        mat = client.post("/api/materials/",
                          json={"name": "TxnMaterial", "unit": "kg",
                                "unit_price": 10.0, "stock_quantity": 500},
                          headers=self.headers).json()
        self.material_id = mat["id"]

    def test_purchase_increases_stock(self):
        resp = client.post("/api/transactions/",
                           json={"type": "purchase", "material_id": self.material_id,
                                 "quantity": 50, "payment_status": "paid"},
                           headers=self.headers)
        assert resp.status_code == 201
        # Check stock increased
        mat = client.get(f"/api/materials/{self.material_id}", headers=self.headers).json()
        assert float(mat["stock_quantity"]) == 550.0

    def test_sale_decreases_stock(self):
        co = client.post("/api/companies/",
                         json={"name": "SaleCo"}, headers=self.headers).json()
        resp = client.post("/api/transactions/",
                           json={"type": "sale_product", "material_id": self.material_id,
                                 "company_id": co["id"], "quantity": 10,
                                 "payment_status": "unpaid"},
                           headers=self.headers)
        assert resp.status_code == 201

    def test_auto_calculate_total(self):
        resp = client.post("/api/transactions/",
                           json={"type": "purchase", "material_id": self.material_id,
                                 "quantity": 5, "payment_status": "paid"},
                           headers=self.headers)
        data = resp.json()
        # unit_price is 10.0, qty is 5, total should be 50
        assert float(data["total_amount"]) == pytest.approx(50.0, abs=0.1)


# ── Invoice Tests ─────────────────────────────────────────────────────────────
class TestInvoices:
    def setup_method(self):
        self.token = get_token("invtest", "pass12345")
        self.headers = auth_headers(self.token)
        co = client.post("/api/companies/",
                         json={"name": "InvCo"}, headers=self.headers).json()
        mat = client.post("/api/materials/",
                          json={"name": "InvMat", "unit": "pcs",
                                "unit_price": 20.0, "stock_quantity": 200},
                          headers=self.headers).json()
        self.company_id = co["id"]
        self.material_id = mat["id"]

    def test_create_invoice(self):
        resp = client.post("/api/invoices/",
                           json={
                               "company_id": self.company_id,
                               "items": [{"material_id": self.material_id,
                                          "quantity": 3, "unit_price": 20.0}]
                           },
                           headers=self.headers)
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "draft"
        assert float(data["total_amount"]) == pytest.approx(60.0)

    def test_confirm_invoice_creates_transactions(self):
        inv = client.post("/api/invoices/",
                          json={"company_id": self.company_id,
                                "items": [{"material_id": self.material_id,
                                           "quantity": 2, "unit_price": 20.0}]},
                          headers=self.headers).json()
        resp = client.post(f"/api/invoices/{inv['id']}/confirm", headers=self.headers)
        assert resp.status_code == 200
        assert resp.json()["status"] == "confirmed"

    def test_cannot_confirm_twice(self):
        inv = client.post("/api/invoices/",
                          json={"company_id": self.company_id,
                                "items": [{"material_id": self.material_id,
                                           "quantity": 1, "unit_price": 20.0}]},
                          headers=self.headers).json()
        client.post(f"/api/invoices/{inv['id']}/confirm", headers=self.headers)
        resp = client.post(f"/api/invoices/{inv['id']}/confirm", headers=self.headers)
        assert resp.status_code == 400


# ── Dashboard Tests ───────────────────────────────────────────────────────────
class TestDashboard:
    def setup_method(self):
        self.token = get_token("dashtest", "pass12345")
        self.headers = auth_headers(self.token)

    def test_summary(self):
        resp = client.get("/api/dashboard/summary", headers=self.headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "total_receivable" in data
        assert "total_payable" in data
        assert "low_stock_count" in data

    def test_notifications(self):
        resp = client.get("/api/dashboard/notifications", headers=self.headers)
        assert resp.status_code == 200
        assert "notifications" in resp.json()
