// Re-export AppStrings from theme.dart so screens can import just this file
export 'theme.dart' show AppStrings, AppTheme;
