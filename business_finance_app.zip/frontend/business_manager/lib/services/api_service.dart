import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:8000/api';
  static const _storage = FlutterSecureStorage();
  static const _tokenKey = 'auth_token';

  // ── Auth token management ─────────────────────────────────────────────────
  static Future<void> saveToken(String token) async {
    await _storage.write(key: _tokenKey, value: token);
  }

  static Future<String?> getToken() async {
    return await _storage.read(key: _tokenKey);
  }

  static Future<void> clearToken() async {
    await _storage.delete(key: _tokenKey);
  }

  static Future<Map<String, String>> _headers() async {
    final token = await getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // ── Generic request helpers ───────────────────────────────────────────────
  static Future<dynamic> get(String path) async {
    final response = await http.get(
      Uri.parse('$baseUrl$path'),
      headers: await _headers(),
    );
    return _handle(response);
  }

  static Future<dynamic> post(String path, Map<String, dynamic> body) async {
    final response = await http.post(
      Uri.parse('$baseUrl$path'),
      headers: await _headers(),
      body: jsonEncode(body),
    );
    return _handle(response);
  }

  static Future<dynamic> put(String path, Map<String, dynamic> body) async {
    final response = await http.put(
      Uri.parse('$baseUrl$path'),
      headers: await _headers(),
      body: jsonEncode(body),
    );
    return _handle(response);
  }

  static Future<void> delete(String path) async {
    final response = await http.delete(
      Uri.parse('$baseUrl$path'),
      headers: await _headers(),
    );
    if (response.statusCode >= 400) {
      throw ApiException(response.statusCode, response.body);
    }
  }

  static dynamic _handle(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return null;
      return jsonDecode(response.body);
    }
    throw ApiException(response.statusCode, response.body);
  }

  // ── Auth ──────────────────────────────────────────────────────────────────
  static Future<String> login(String username, String password) async {
    final data = await post('/auth/login', {
      'username': username,
      'password': password,
    });
    final token = data['access_token'] as String;
    await saveToken(token);
    return token;
  }

  static Future<void> logout() async => clearToken();

  static Future<Map<String, dynamic>> register(String username, String password) async {
    return await post('/auth/register', {'username': username, 'password': password});
  }

  static Future<void> changePassword(String currentPw, String newPw) async {
    await post('/auth/change-password', {
      'current_password': currentPw,
      'new_password': newPw,
    });
  }

  // ── Dashboard ─────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getDashboardSummary() async {
    return await get('/dashboard/summary');
  }

  static Future<Map<String, dynamic>> getNotifications() async {
    return await get('/dashboard/notifications');
  }

  // ── Companies ─────────────────────────────────────────────────────────────
  static Future<List<dynamic>> getCompanies() async => await get('/companies');

  static Future<Map<String, dynamic>> getCompany(String id) async =>
      await get('/companies/$id');

  static Future<Map<String, dynamic>> createCompany(Map<String, dynamic> data) async =>
      await post('/companies', data);

  static Future<Map<String, dynamic>> updateCompany(String id, Map<String, dynamic> data) async =>
      await put('/companies/$id', data);

  static Future<void> deleteCompany(String id) async => await delete('/companies/$id');

  static Future<List<dynamic>> getLedger(String companyId) async =>
      await get('/transactions/ledger/$companyId');

  // ── Materials ─────────────────────────────────────────────────────────────
  static Future<List<dynamic>> getMaterials() async => await get('/materials');

  static Future<Map<String, dynamic>> createMaterial(Map<String, dynamic> data) async =>
      await post('/materials', data);

  static Future<Map<String, dynamic>> updateMaterial(String id, Map<String, dynamic> data) async =>
      await put('/materials/$id', data);

  static Future<void> deleteMaterial(String id) async => await delete('/materials/$id');

  static Future<List<dynamic>> getLowStockAlerts() async =>
      await get('/materials/low-stock/alerts');

  // ── Transactions ──────────────────────────────────────────────────────────
  static Future<List<dynamic>> getTransactions({
    String? companyId, String? materialId, String? type
  }) async {
    final params = <String, String>{};
    if (companyId != null) params['company_id'] = companyId;
    if (materialId != null) params['material_id'] = materialId;
    if (type != null) params['type'] = type;
    final query = params.isEmpty ? '' : '?${Uri(queryParameters: params).query}';
    return await get('/transactions$query');
  }

  static Future<Map<String, dynamic>> createTransaction(Map<String, dynamic> data) async =>
      await post('/transactions', data);

  static Future<Map<String, dynamic>> updateTransaction(String id, Map<String, dynamic> data) async =>
      await put('/transactions/$id', data);

  // ── Payments ──────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> addPayment(Map<String, dynamic> data) async =>
      await post('/payments', data);

  static Future<List<dynamic>> getPaymentsForTransaction(String transactionId) async =>
      await get('/payments/transaction/$transactionId');

  // ── Expenses ──────────────────────────────────────────────────────────────
  static Future<List<dynamic>> getExpenses({int? year, int? month, String? category}) async {
    final params = <String, String>{};
    if (year != null) params['year'] = year.toString();
    if (month != null) params['month'] = month.toString();
    if (category != null) params['category'] = category;
    final query = params.isEmpty ? '' : '?${Uri(queryParameters: params).query}';
    return await get('/expenses$query');
  }

  static Future<Map<String, dynamic>> createExpense(Map<String, dynamic> data) async =>
      await post('/expenses', data);

  static Future<Map<String, dynamic>> updateExpense(String id, Map<String, dynamic> data) async =>
      await put('/expenses/$id', data);

  static Future<void> deleteExpense(String id) async => await delete('/expenses/$id');

  static Future<Map<String, dynamic>> getExpenseSummary(int year) async =>
      await get('/expenses/summary?year=$year');

  // ── Invoices ──────────────────────────────────────────────────────────────
  static Future<List<dynamic>> getInvoices({String? status, String? companyId}) async {
    final params = <String, String>{};
    if (status != null) params['status'] = status;
    if (companyId != null) params['company_id'] = companyId;
    final query = params.isEmpty ? '' : '?${Uri(queryParameters: params).query}';
    return await get('/invoices$query');
  }

  static Future<Map<String, dynamic>> createInvoice(Map<String, dynamic> data) async =>
      await post('/invoices', data);

  static Future<Map<String, dynamic>> confirmInvoice(String id) async =>
      await post('/invoices/$id/confirm', {});

  static Future<Map<String, dynamic>> generateInvoicePdf(String id) async =>
      await post('/invoices/$id/generate-pdf', {});

  static String invoicePdfDownloadUrl(String id) =>
      '$baseUrl/invoices/$id/download-pdf';

  // ── Backup & Export ───────────────────────────────────────────────────────
  static String exportUrl(String type) => '$baseUrl/backup/export/$type';

  static Future<Map<String, dynamic>> createBackup() async =>
      await post('/backup/database', {});
}

class ApiException implements Exception {
  final int statusCode;
  final String body;
  ApiException(this.statusCode, this.body);

  @override
  String toString() => 'ApiException($statusCode): $body';

  String get message {
    try {
      final decoded = jsonDecode(body);
      return decoded['detail'] ?? body;
    } catch (_) {
      return body;
    }
  }
}
