import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';

class MaterialsScreen extends StatefulWidget {
  const MaterialsScreen({super.key});

  @override
  State<MaterialsScreen> createState() => _MaterialsScreenState();
}

class _MaterialsScreenState extends State<MaterialsScreen> {
  List<dynamic> _materials = [];
  bool _loading = true;
  String _search = '';
  final _numFmt = NumberFormat('#,##0.00');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.getMaterials();
      setState(() { _materials = data; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  List<dynamic> get _filtered => _materials
      .where((m) => m['name'].toString().toLowerCase().contains(_search.toLowerCase()))
      .toList();

  void _openDialog({Map<String, dynamic>? existing}) {
    showDialog(
      context: context,
      builder: (_) => _MaterialDialog(existing: existing, onSaved: _load),
    );
  }

  Future<void> _delete(String id, String name) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Material'),
        content: Text('Delete "$name"? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      try {
        await ApiService.deleteMaterial(id);
        _load();
      } on ApiException catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Materials & Inventory'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(icon: const Icon(Icons.add), onPressed: () => _openDialog()),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Search materials...',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => _search = v),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('No materials found.'))
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: _filtered.length,
                        itemBuilder: (_, i) {
                          final m = _filtered[i] as Map<String, dynamic>;
                          final isLow = m['is_low_stock'] == true;
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: isLow
                                    ? AppTheme.warning.withOpacity(0.15)
                                    : AppTheme.primary.withOpacity(0.1),
                                child: Icon(
                                  isLow ? Icons.warning_amber : Icons.inventory_2,
                                  color: isLow ? AppTheme.warning : AppTheme.primary,
                                  size: 20,
                                ),
                              ),
                              title: Row(
                                children: [
                                  Text(m['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
                                  if (isLow) ...[
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: AppTheme.warning.withOpacity(0.15),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: const Text('LOW STOCK',
                                        style: TextStyle(color: AppTheme.warning, fontSize: 10, fontWeight: FontWeight.bold)),
                                    ),
                                  ],
                                ],
                              ),
                              subtitle: Text(
                                '${m['type'] ?? 'General'}  •  '
                                'Stock: ${_numFmt.format(m['stock_quantity'])} ${m['unit']}  •  '
                                'Price: ${_numFmt.format(m['unit_price'])} / ${m['unit']}',
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.edit, size: 18),
                                    onPressed: () => _openDialog(existing: m),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete, size: 18, color: AppTheme.danger),
                                    onPressed: () => _delete(m['id'], m['name']),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _MaterialDialog extends StatefulWidget {
  final Map<String, dynamic>? existing;
  final VoidCallback onSaved;

  const _MaterialDialog({this.existing, required this.onSaved});

  @override
  State<_MaterialDialog> createState() => _MaterialDialogState();
}

class _MaterialDialogState extends State<_MaterialDialog> {
  final _formKey = GlobalKey<FormState>();
  late final _nameCtrl = TextEditingController(text: widget.existing?['name'] ?? '');
  late final _typeCtrl = TextEditingController(text: widget.existing?['type'] ?? '');
  late final _unitCtrl = TextEditingController(text: widget.existing?['unit'] ?? '');
  late final _priceCtrl = TextEditingController(
      text: (widget.existing?['unit_price'] ?? '').toString());
  late final _stockCtrl = TextEditingController(
      text: (widget.existing?['stock_quantity'] ?? '0').toString());
  late final _thresholdCtrl = TextEditingController(
      text: (widget.existing?['low_stock_threshold'] ?? '').toString());
  bool _saving = false;

  bool get _isNew => widget.existing?['id'] == null;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final data = {
        'name': _nameCtrl.text.trim(),
        'type': _typeCtrl.text.trim().isEmpty ? null : _typeCtrl.text.trim(),
        'unit': _unitCtrl.text.trim(),
        'unit_price': double.parse(_priceCtrl.text),
        'stock_quantity': double.tryParse(_stockCtrl.text) ?? 0,
        'low_stock_threshold': _thresholdCtrl.text.trim().isEmpty
            ? null
            : double.tryParse(_thresholdCtrl.text),
      };
      if (_isNew) {
        await ApiService.createMaterial(data);
      } else {
        await ApiService.updateMaterial(widget.existing!['id'], data);
      }
      widget.onSaved();
      Navigator.pop(context);
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isNew ? 'Add Material' : 'Edit Material'),
      content: Form(
        key: _formKey,
        child: SizedBox(
          width: 440,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Material Name *'),
              validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: TextFormField(
                  controller: _typeCtrl,
                  decoration: const InputDecoration(labelText: 'Category / Type'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _unitCtrl,
                  decoration: const InputDecoration(labelText: 'Unit (kg/liter/piece) *'),
                  validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: TextFormField(
                  controller: _priceCtrl,
                  decoration: const InputDecoration(labelText: 'Unit Price *'),
                  keyboardType: TextInputType.number,
                  validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _stockCtrl,
                  decoration: const InputDecoration(labelText: 'Stock Quantity'),
                  keyboardType: TextInputType.number,
                ),
              ),
            ]),
            const SizedBox(height: 12),
            TextFormField(
              controller: _thresholdCtrl,
              decoration: const InputDecoration(
                labelText: 'Low Stock Threshold (optional)',
                helperText: 'Alert when stock falls below this',
              ),
              keyboardType: TextInputType.number,
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          child: Text(_isNew ? 'Add' : 'Save'),
        ),
      ],
    );
  }
}
