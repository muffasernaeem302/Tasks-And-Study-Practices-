import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';
import 'ledger_screen.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  List<dynamic> _companies = [];
  bool _loading = true;
  final _fmt = NumberFormat('#,##0.00');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.getCompanies();
      setState(() { _companies = data; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _openAddDialog({Map<String, dynamic>? existing}) {
    showDialog(
      context: context,
      builder: (_) => _CompanyDialog(
        existing: existing,
        onSaved: _load,
        companies: _companies,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Companies & Clients'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(icon: const Icon(Icons.add), onPressed: () => _openAddDialog()),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _companies.isEmpty
              ? const Center(child: Text('No companies yet. Add one to get started.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _companies.length,
                  itemBuilder: (_, i) {
                    final c = _companies[i] as Map<String, dynamic>;
                    final subs = (c['sub_companies'] as List?) ?? [];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ExpansionTile(
                        leading: const Icon(Icons.business, color: AppTheme.primary),
                        title: Text(c['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(
                          'Balance: ${_fmt.format(c['current_balance'] ?? 0)}',
                          style: TextStyle(
                            color: (c['current_balance'] ?? 0) >= 0 ? AppTheme.success : AppTheme.danger,
                          ),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton(
                              child: const Text('Ledger'),
                              onPressed: () => Navigator.push(context, MaterialPageRoute(
                                builder: (_) => LedgerScreen(companyId: c['id'], companyName: c['name']),
                              )),
                            ),
                            IconButton(icon: const Icon(Icons.edit, size: 18), onPressed: () => _openAddDialog(existing: c)),
                          ],
                        ),
                        children: [
                          ...subs.map((sub) => ListTile(
                            contentPadding: const EdgeInsets.only(left: 40, right: 16),
                            leading: const Icon(Icons.subdirectory_arrow_right, color: AppTheme.textSecondary),
                            title: Text(sub['name']),
                            onTap: () => Navigator.push(context, MaterialPageRoute(
                              builder: (_) => LedgerScreen(companyId: sub['id'], companyName: sub['name']),
                            )),
                          )),
                          TextButton.icon(
                            icon: const Icon(Icons.add, size: 16),
                            label: const Text('Add Sub-Company'),
                            onPressed: () => _openAddDialog(existing: {'parent_company_id': c['id']}),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}

class _CompanyDialog extends StatefulWidget {
  final Map<String, dynamic>? existing;
  final VoidCallback onSaved;
  final List<dynamic> companies;

  const _CompanyDialog({this.existing, required this.onSaved, required this.companies});

  @override
  State<_CompanyDialog> createState() => _CompanyDialogState();
}

class _CompanyDialogState extends State<_CompanyDialog> {
  final _formKey = GlobalKey<FormState>();
  late final _nameCtrl = TextEditingController(text: widget.existing?['name'] ?? '');
  late final _contactCtrl = TextEditingController(text: widget.existing?['contact_info'] ?? '');
  late final _balanceCtrl = TextEditingController(
    text: (widget.existing?['opening_balance'] ?? '0').toString());
  String? _parentId = widget.existing?['parent_company_id'];
  bool _saving = false;

  bool get _isNew => widget.existing?['id'] == null;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final data = {
        'name': _nameCtrl.text.trim(),
        'contact_info': _contactCtrl.text.trim().isEmpty ? null : _contactCtrl.text.trim(),
        'opening_balance': double.tryParse(_balanceCtrl.text) ?? 0,
        'parent_company_id': _parentId,
      };
      if (_isNew) {
        await ApiService.createCompany(data);
      } else {
        await ApiService.updateCompany(widget.existing!['id'], data);
      }
      widget.onSaved();
      Navigator.pop(context);
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isNew ? 'Add Company' : 'Edit Company'),
      content: Form(
        key: _formKey,
        child: SizedBox(
          width: 400,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Company Name *'),
              validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null),
            const SizedBox(height: 12),
            TextFormField(controller: _contactCtrl,
              decoration: const InputDecoration(labelText: 'Contact Info')),
            const SizedBox(height: 12),
            TextFormField(controller: _balanceCtrl,
              decoration: const InputDecoration(labelText: 'Opening Balance'),
              keyboardType: TextInputType.number),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          child: Text(_isNew ? 'Add' : 'Save'),
        ),
      ],
    );
  }
}
