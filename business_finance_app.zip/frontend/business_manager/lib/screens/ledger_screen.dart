import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';

class LedgerScreen extends StatefulWidget {
  final String companyId;
  final String companyName;

  const LedgerScreen({super.key, required this.companyId, required this.companyName});

  @override
  State<LedgerScreen> createState() => _LedgerScreenState();
}

class _LedgerScreenState extends State<LedgerScreen> {
  List<dynamic> _entries = [];
  bool _loading = true;
  final _numFmt = NumberFormat('#,##0.00');
  final _dateFmt = DateFormat('dd MMM yyyy  HH:mm');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.getLedger(widget.companyId);
      setState(() { _entries = data; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Color _balanceColor(double balance) => balance >= 0 ? AppTheme.success : AppTheme.danger;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ledger — ${widget.companyName}'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _entries.isEmpty
              ? const Center(child: Text('No transactions for this company.'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  scrollDirection: Axis.vertical,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      headingRowColor: WidgetStateProperty.all(AppTheme.primary.withOpacity(0.08)),
                      columns: const [
                        DataColumn(label: Text('Date', style: TextStyle(fontWeight: FontWeight.bold))),
                        DataColumn(label: Text('Type', style: TextStyle(fontWeight: FontWeight.bold))),
                        DataColumn(label: Text('Material', style: TextStyle(fontWeight: FontWeight.bold))),
                        DataColumn(label: Text('Qty', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                        DataColumn(label: Text('Total', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                        DataColumn(label: Text('Paid', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                        DataColumn(label: Text('Due', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                        DataColumn(label: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
                        DataColumn(label: Text('Balance', style: TextStyle(fontWeight: FontWeight.bold)), numeric: true),
                      ],
                      rows: _entries.map((e) {
                        final balance = (e['running_balance'] as num).toDouble();
                        return DataRow(cells: [
                          DataCell(Text(_dateFmt.format(DateTime.parse(e['date_time'])))),
                          DataCell(Text((e['type'] as String).replaceAll('_', ' '))),
                          DataCell(Text(e['material_name'] ?? '')),
                          DataCell(Text(_numFmt.format(e['quantity']))),
                          DataCell(Text(_numFmt.format(e['total_amount']))),
                          DataCell(Text(_numFmt.format(e['amount_paid']))),
                          DataCell(Text(_numFmt.format(e['amount_due']))),
                          DataCell(_StatusChip(e['payment_status'])),
                          DataCell(Text(
                            _numFmt.format(balance),
                            style: TextStyle(fontWeight: FontWeight.bold, color: _balanceColor(balance)),
                          )),
                        ]);
                      }).toList(),
                    ),
                  ),
                ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;
  const _StatusChip(this.status);

  @override
  Widget build(BuildContext context) {
    final color = status == 'paid' ? AppTheme.success
        : status == 'partial' ? AppTheme.warning
        : AppTheme.danger;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(status.toUpperCase(),
          style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }
}
