import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';
import 'login_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          _Section(
            title: 'Account',
            children: [
              _SettingsTile(
                icon: Icons.lock_outline,
                title: 'Change Password',
                subtitle: 'Update your login password',
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => const _ChangePasswordDialog(),
                ),
              ),
              _SettingsTile(
                icon: Icons.logout,
                title: 'Sign Out',
                subtitle: 'Log out of this device',
                iconColor: AppTheme.danger,
                onTap: () async {
                  await ApiService.logout();
                  if (context.mounted) {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginScreen()),
                      (_) => false,
                    );
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          _Section(
            title: 'Data Export',
            children: [
              _SettingsTile(
                icon: Icons.download,
                title: 'Export Transactions (CSV)',
                subtitle: 'Download all transaction records',
                onTap: () {
                  final url = ApiService.exportUrl('transactions');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Open in browser: $url')));
                },
              ),
              _SettingsTile(
                icon: Icons.download,
                title: 'Export Expenses (CSV)',
                subtitle: 'Download all expense records',
                onTap: () {
                  final url = ApiService.exportUrl('expenses');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Open in browser: $url')));
                },
              ),
              _SettingsTile(
                icon: Icons.download,
                title: 'Export Companies (CSV)',
                subtitle: 'Download all company records',
                onTap: () {
                  final url = ApiService.exportUrl('companies');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Open in browser: $url')));
                },
              ),
              _SettingsTile(
                icon: Icons.download,
                title: 'Export Materials (CSV)',
                subtitle: 'Download all material/inventory records',
                onTap: () {
                  final url = ApiService.exportUrl('materials');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Open in browser: $url')));
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          _Section(
            title: 'Backup',
            children: [
              _SettingsTile(
                icon: Icons.backup,
                title: 'Backup Database',
                subtitle: 'Create a full PostgreSQL dump (.sql)',
                onTap: () async {
                  try {
                    final result = await ApiService.createBackup();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Backup created: ${result['filename'] ?? 'done'}'),
                          backgroundColor: AppTheme.success));
                  } on ApiException catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error: ${e.message}'), backgroundColor: AppTheme.danger));
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          _Section(
            title: 'About',
            children: [
              _SettingsTile(
                icon: Icons.info_outline,
                title: 'Business Finance Manager',
                subtitle: 'Version 1.0.0  •  Built with Flutter & FastAPI',
                onTap: null,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _Section({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(title, style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: AppTheme.primary,
            fontSize: 13,
            letterSpacing: 0.5,
          )),
        ),
        Card(child: Column(children: children)),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  final Color iconColor;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
    this.iconColor = AppTheme.primary,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: iconColor),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
      trailing: onTap != null ? const Icon(Icons.chevron_right, color: AppTheme.textSecondary) : null,
      onTap: onTap,
    );
  }
}

class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog();

  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _formKey = GlobalKey<FormState>();
  final _currentCtrl = TextEditingController();
  final _newCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _saving = false;
  bool _obscureCurrent = true;
  bool _obscureNew = true;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await ApiService.changePassword(_currentCtrl.text, _newCtrl.text);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password changed successfully'),
            backgroundColor: AppTheme.success));
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), backgroundColor: AppTheme.danger));
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Change Password'),
      content: Form(
        key: _formKey,
        child: SizedBox(
          width: 380,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(
              controller: _currentCtrl,
              obscureText: _obscureCurrent,
              decoration: InputDecoration(
                labelText: 'Current Password',
                suffixIcon: IconButton(
                  icon: Icon(_obscureCurrent ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _obscureCurrent = !_obscureCurrent),
                ),
              ),
              validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _newCtrl,
              obscureText: _obscureNew,
              decoration: InputDecoration(
                labelText: 'New Password',
                suffixIcon: IconButton(
                  icon: Icon(_obscureNew ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _obscureNew = !_obscureNew),
                ),
              ),
              validator: (v) => (v?.isEmpty ?? true) ? 'Required' : ((v!.length < 6) ? 'Min 6 characters' : null),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _confirmCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Confirm New Password'),
              validator: (v) => v != _newCtrl.text ? 'Passwords do not match' : null,
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          child: const Text('Change Password'),
        ),
      ],
    );
  }
}
