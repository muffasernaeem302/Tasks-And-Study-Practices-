import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';

class TransactionEntryScreen extends StatefulWidget {
  const TransactionEntryScreen({super.key});

  @override
  State<TransactionEntryScreen> createState() => _TransactionEntryScreenState();
}

class _TransactionEntryScreenState extends State<TransactionEntryScreen> {
  final _formKey = GlobalKey<FormState>();

  // Form state
  String _txnType = 'purchase';
  Map<String, dynamic>? _selectedCompany;
  Map<String, dynamic>? _selectedMaterial;
  final _qtyCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  String _paymentStatus = 'unpaid';
  final _paidCtrl = TextEditingController(text: '0');
  DateTime _dateTime = DateTime.now();
  final _notesCtrl = TextEditingController();

  List<dynamic> _companies = [];
  List<dynamic> _materials = [];
  bool _loading = false;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _loadData();
    _qtyCtrl.addListener(_recalculate);
    _priceCtrl.addListener(_recalculate);
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final companies = await ApiService.getCompanies();
      final materials = await ApiService.getMaterials();
      setState(() { _companies = companies; _materials = materials; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _onMaterialSelected(Map<String, dynamic>? m) {
    setState(() {
      _selectedMaterial = m;
      if (m != null) {
        _priceCtrl.text = m['unit_price'].toString();
        _recalculate();
      }
    });
  }

  void _recalculate() {
    final qty = double.tryParse(_qtyCtrl.text) ?? 0;
    final price = double.tryParse(_priceCtrl.text) ?? 0;
    final amount = qty * price;
    if (amount > 0) {
      _amountCtrl.removeListener(_recalculate);
      _amountCtrl.text = amount.toStringAsFixed(2);
      _amountCtrl.addListener(_recalculate);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedMaterial == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a material')));
      return;
    }

    setState(() => _submitting = true);
    try {
      await ApiService.createTransaction({
        'type': _txnType,
        'company_id': _selectedCompany?['id'],
        'material_id': _selectedMaterial!['id'],
        'quantity': double.parse(_qtyCtrl.text),
        'unit_price': double.tryParse(_priceCtrl.text),
        'total_amount': double.tryParse(_amountCtrl.text),
        'payment_status': _paymentStatus,
        'amount_paid': double.tryParse(_paidCtrl.text) ?? 0,
        'date_time': _dateTime.toIso8601String(),
        'notes': _notesCtrl.text.isEmpty ? null : _notesCtrl.text,
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaction saved!'), backgroundColor: AppTheme.success));
      _resetForm();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.message}'), backgroundColor: AppTheme.danger));
    } finally {
      setState(() => _submitting = false);
    }
  }

  void _resetForm() {
    setState(() {
      _txnType = 'purchase';
      _selectedCompany = null;
      _selectedMaterial = null;
      _paymentStatus = 'unpaid';
      _dateTime = DateTime.now();
    });
    _qtyCtrl.clear();
    _priceCtrl.clear();
    _amountCtrl.clear();
    _paidCtrl.text = '0';
    _notesCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New Transaction')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 600),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text('Transaction Details',
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold)),
                            const SizedBox(height: 20),

                            // Transaction Type
                            DropdownButtonFormField<String>(
                              value: _txnType,
                              decoration: const InputDecoration(labelText: 'Transaction Type'),
                              items: AppStrings.transactionTypeLabels.entries.map((e) =>
                                DropdownMenuItem(value: e.key, child: Text(e.value))
                              ).toList(),
                              onChanged: (v) => setState(() => _txnType = v!),
                            ),
                            const SizedBox(height: 16),

                            // Company
                            DropdownButtonFormField<Map<String, dynamic>>(
                              value: _selectedCompany,
                              decoration: const InputDecoration(labelText: 'Company / Client (optional)'),
                              items: _companies.map((c) => DropdownMenuItem(
                                value: c as Map<String, dynamic>,
                                child: Text(c['name']),
                              )).toList(),
                              onChanged: (v) => setState(() => _selectedCompany = v),
                            ),
                            const SizedBox(height: 16),

                            // Material
                            DropdownButtonFormField<Map<String, dynamic>>(
                              value: _selectedMaterial,
                              decoration: const InputDecoration(labelText: 'Material / Item *'),
                              items: _materials.map((m) => DropdownMenuItem(
                                value: m as Map<String, dynamic>,
                                child: Text('${m['name']} (${m['unit']})'),
                              )).toList(),
                              onChanged: _onMaterialSelected,
                              validator: (v) => v == null ? 'Required' : null,
                            ),
                            const SizedBox(height: 16),

                            // Qty + Price + Amount
                            Row(children: [
                              Expanded(child: TextFormField(
                                controller: _qtyCtrl,
                                decoration: InputDecoration(
                                  labelText: 'Quantity',
                                  suffixText: _selectedMaterial?['unit'] ?? '',
                                ),
                                keyboardType: TextInputType.number,
                                validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
                              )),
                              const SizedBox(width: 12),
                              Expanded(child: TextFormField(
                                controller: _priceCtrl,
                                decoration: const InputDecoration(labelText: 'Unit Price'),
                                keyboardType: TextInputType.number,
                              )),
                              const SizedBox(width: 12),
                              Expanded(child: TextFormField(
                                controller: _amountCtrl,
                                decoration: const InputDecoration(labelText: 'Total Amount'),
                                keyboardType: TextInputType.number,
                              )),
                            ]),
                            const SizedBox(height: 16),

                            // Payment Status
                            DropdownButtonFormField<String>(
                              value: _paymentStatus,
                              decoration: const InputDecoration(labelText: 'Payment Status'),
                              items: const [
                                DropdownMenuItem(value: 'paid', child: Text('Paid')),
                                DropdownMenuItem(value: 'unpaid', child: Text('Unpaid')),
                                DropdownMenuItem(value: 'partial', child: Text('Partially Paid')),
                              ],
                              onChanged: (v) => setState(() => _paymentStatus = v!),
                            ),
                            if (_paymentStatus == 'partial') ...[
                              const SizedBox(height: 12),
                              TextFormField(
                                controller: _paidCtrl,
                                decoration: const InputDecoration(labelText: 'Amount Paid'),
                                keyboardType: TextInputType.number,
                              ),
                            ],
                            const SizedBox(height: 16),

                            // Date/Time
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.calendar_today, color: AppTheme.primary),
                              title: Text(DateFormat('dd MMM yyyy  HH:mm').format(_dateTime)),
                              subtitle: const Text('Transaction date & time'),
                              onTap: () async {
                                final d = await showDatePicker(
                                  context: context,
                                  initialDate: _dateTime,
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime.now().add(const Duration(days: 365)),
                                );
                                if (d != null) setState(() => _dateTime = d);
                              },
                            ),
                            const SizedBox(height: 8),

                            // Notes
                            TextFormField(
                              controller: _notesCtrl,
                              decoration: const InputDecoration(labelText: 'Notes (optional)'),
                              maxLines: 2,
                            ),
                            const SizedBox(height: 24),

                            ElevatedButton.icon(
                              onPressed: _submitting ? null : _submit,
                              icon: _submitting
                                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                  : const Icon(Icons.save),
                              label: const Text('Save Transaction'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
    );
  }
}
