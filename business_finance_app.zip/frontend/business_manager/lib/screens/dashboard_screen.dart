import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _summary;
  bool _loading = true;
  String? _error;
  final _fmt = NumberFormat('#,##0.00');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final summary = await ApiService.getDashboardSummary();
      setState(() { _summary = summary; _loading = false; });
    } on ApiException catch (e) {
      setState(() { _error = e.message; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!, style: const TextStyle(color: AppTheme.danger)))
              : _buildBody(),
    );
  }

  Widget _buildBody() {
    final s = _summary!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Overview', style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold, color: AppTheme.textPrimary,
          )),
          const SizedBox(height: 20),
          // Summary cards
          Row(
            children: [
              _SummaryCard(
                label: 'Total Receivable',
                value: _fmt.format(s['total_receivable'] ?? 0),
                icon: Icons.arrow_circle_down,
                color: AppTheme.success,
              ),
              const SizedBox(width: 16),
              _SummaryCard(
                label: 'Total Payable',
                value: _fmt.format(s['total_payable'] ?? 0),
                icon: Icons.arrow_circle_up,
                color: AppTheme.danger,
              ),
              const SizedBox(width: 16),
              _SummaryCard(
                label: 'Unpaid Invoices',
                value: '${s['unpaid_invoices'] ?? 0}',
                icon: Icons.receipt_long,
                color: AppTheme.warning,
              ),
              const SizedBox(width: 16),
              _SummaryCard(
                label: 'Low Stock Items',
                value: '${s['low_stock_count'] ?? 0}',
                icon: Icons.warning_amber,
                color: AppTheme.danger,
              ),
            ],
          ),
          const SizedBox(height: 32),
          // Low stock alerts
          if ((s['low_stock_items'] as List?)?.isNotEmpty == true) ...[
            Text('Low Stock Alerts', style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            )),
            const SizedBox(height: 12),
            ...(s['low_stock_items'] as List).map((item) => _LowStockTile(item: item)),
          ],
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _SummaryCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 12),
              Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold, color: color,
              )),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}

class _LowStockTile extends StatelessWidget {
  final Map<String, dynamic> item;
  const _LowStockTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: const Icon(Icons.warning_amber, color: AppTheme.warning),
        title: Text(item['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('Stock: ${item['stock']} ${item['unit']} (threshold: ${item['threshold']} ${item['unit']})'),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: AppTheme.warning.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Text('LOW', style: TextStyle(color: AppTheme.warning, fontWeight: FontWeight.bold, fontSize: 12)),
        ),
      ),
    );
  }
}
