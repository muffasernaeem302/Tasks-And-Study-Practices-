import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../services/api_service.dart';
import 'login_screen.dart';
import 'dashboard_screen.dart';
import 'transaction_entry_screen.dart';
import 'companies_screen.dart';
import 'materials_screen.dart';
import 'expenses_screen.dart';
import 'invoices_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<_NavItem> _navItems = [
    _NavItem(Icons.dashboard_outlined, Icons.dashboard, 'Dashboard'),
    _NavItem(Icons.add_circle_outline, Icons.add_circle, 'New Transaction'),
    _NavItem(Icons.business_outlined, Icons.business, 'Companies'),
    _NavItem(Icons.inventory_2_outlined, Icons.inventory_2, 'Materials'),
    _NavItem(Icons.receipt_long_outlined, Icons.receipt_long, 'Invoices'),
    _NavItem(Icons.payments_outlined, Icons.payments, 'Expenses'),
    _NavItem(Icons.settings_outlined, Icons.settings, 'Settings'),
  ];

  Widget get _currentScreen {
    switch (_selectedIndex) {
      case 0: return const DashboardScreen();
      case 1: return const TransactionEntryScreen();
      case 2: return const CompaniesScreen();
      case 3: return const MaterialsScreen();
      case 4: return const InvoicesScreen();
      case 5: return const ExpensesScreen();
      case 6: return const SettingsScreen();
      default: return const DashboardScreen();
    }
  }

  Future<void> _logout() async {
    await ApiService.logout();
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // ── Side Navigation Rail ─────────────────────────────────────────
          NavigationRail(
            backgroundColor: AppTheme.primary,
            selectedIndex: _selectedIndex,
            onDestinationSelected: (i) => setState(() => _selectedIndex = i),
            extended: true,
            minExtendedWidth: 200,
            leading: const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Row(
                children: [
                  Icon(Icons.account_balance, color: Colors.white, size: 24),
                  SizedBox(width: 8),
                  Text('Finance Mgr', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            trailing: Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: IconButton(
                icon: const Icon(Icons.logout, color: Colors.white70),
                onPressed: _logout,
                tooltip: 'Logout',
              ),
            ),
            selectedIconTheme: const IconThemeData(color: Colors.white),
            unselectedIconTheme: const IconThemeData(color: Colors.white60),
            selectedLabelTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            unselectedLabelTextStyle: const TextStyle(color: Colors.white60),
            indicatorColor: Colors.white24,
            destinations: _navItems.map((item) => NavigationRailDestination(
              icon: Icon(item.outlinedIcon),
              selectedIcon: Icon(item.filledIcon),
              label: Text(item.label),
            )).toList(),
          ),
          // ── Main Content ─────────────────────────────────────────────────
          Expanded(child: _currentScreen),
        ],
      ),
    );
  }
}

class _NavItem {
  final IconData outlinedIcon;
  final IconData filledIcon;
  final String label;
  const _NavItem(this.outlinedIcon, this.filledIcon, this.label);
}
