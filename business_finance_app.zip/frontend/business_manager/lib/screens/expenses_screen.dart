import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});

  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  List<dynamic> _expenses = [];
  bool _loading = true;
  int _year = DateTime.now().year;
  int? _month;
  Map<String, dynamic>? _summary;
  final _numFmt = NumberFormat('#,##0.00');
  final _dateFmt = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final expenses = await ApiService.getExpenses(year: _year, month: _month);
      final summary = await ApiService.getExpenseSummary(_year);
      setState(() {
        _expenses = expenses;
        _summary = summary;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _openDialog({Map<String, dynamic>? existing}) {
    showDialog(
      context: context,
      builder: (_) => _ExpenseDialog(existing: existing, onSaved: _load),
    );
  }

  Future<void> _delete(String id) async {
    try {
      await ApiService.deleteExpense(id);
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final yearlyTotal = _summary?['yearly_total'] ?? 0.0;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Expenses'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(icon: const Icon(Icons.add), onPressed: () => _openDialog()),
        ],
      ),
      body: Column(
        children: [
          // ── Filter bar ──────────────────────────────────────────────────
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                const Text('Year:', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: _year,
                  items: List.generate(6, (i) => DateTime.now().year - i)
                      .map((y) => DropdownMenuItem(value: y, child: Text(y.toString())))
                      .toList(),
                  onChanged: (v) { setState(() { _year = v!; _month = null; }); _load(); },
                ),
                const SizedBox(width: 16),
                const Text('Month:', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(width: 8),
                DropdownButton<int?>(
                  value: _month,
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All')),
                    ...List.generate(12, (i) => DropdownMenuItem(
                        value: i + 1,
                        child: Text(DateFormat('MMMM').format(DateTime(0, i + 1)))))
                  ],
                  onChanged: (v) { setState(() => _month = v); _load(); },
                ),
                const Spacer(),
                if (_summary != null)
                  Text('Year Total: ${_numFmt.format(yearlyTotal)}',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primary)),
              ],
            ),
          ),
          // ── List ────────────────────────────────────────────────────────
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _expenses.isEmpty
                    ? const Center(child: Text('No expenses for selected period.'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _expenses.length,
                        itemBuilder: (_, i) {
                          final e = _expenses[i] as Map<String, dynamic>;
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: AppTheme.primary.withOpacity(0.1),
                                child: const Icon(Icons.payments_outlined, color: AppTheme.primary, size: 20),
                              ),
                              title: Text(e['category'],
                                style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: Text(
                                '${e['description'] ?? ''}  •  '
                                '${_dateFmt.format(DateTime.parse(e['date_time']))}',
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(_numFmt.format(e['amount']),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: AppTheme.danger,
                                        fontSize: 15)),
                                  const SizedBox(width: 8),
                                  IconButton(
                                    icon: const Icon(Icons.edit, size: 18),
                                    onPressed: () => _openDialog(existing: e),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete, size: 18, color: AppTheme.danger),
                                    onPressed: () => _delete(e['id']),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _ExpenseDialog extends StatefulWidget {
  final Map<String, dynamic>? existing;
  final VoidCallback onSaved;

  const _ExpenseDialog({this.existing, required this.onSaved});

  @override
  State<_ExpenseDialog> createState() => _ExpenseDialogState();
}

class _ExpenseDialogState extends State<_ExpenseDialog> {
  final _formKey = GlobalKey<FormState>();
  late final _categoryCtrl = TextEditingController(text: widget.existing?['category'] ?? '');
  late final _descCtrl = TextEditingController(text: widget.existing?['description'] ?? '');
  late final _amountCtrl = TextEditingController(
      text: (widget.existing?['amount'] ?? '').toString());
  DateTime _dateTime = widget.existing != null
      ? DateTime.parse(widget.existing!['date_time'])
      : DateTime.now();
  bool _saving = false;

  bool get _isNew => widget.existing?['id'] == null;

  static const _categories = [
    'Rent', 'Utilities', 'Transport', 'Salaries', 'Raw Materials',
    'Equipment', 'Marketing', 'Repairs', 'Miscellaneous'
  ];

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final data = {
        'category': _categoryCtrl.text.trim(),
        'description': _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
        'amount': double.parse(_amountCtrl.text),
        'date_time': _dateTime.toIso8601String(),
      };
      if (_isNew) {
        await ApiService.createExpense(data);
      } else {
        await ApiService.updateExpense(widget.existing!['id'], data);
      }
      widget.onSaved();
      Navigator.pop(context);
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isNew ? 'Add Expense' : 'Edit Expense'),
      content: Form(
        key: _formKey,
        child: SizedBox(
          width: 400,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Autocomplete<String>(
              initialValue: TextEditingValue(text: _categoryCtrl.text),
              optionsBuilder: (v) => _categories
                  .where((c) => c.toLowerCase().contains(v.text.toLowerCase())),
              onSelected: (v) => _categoryCtrl.text = v,
              fieldViewBuilder: (_, ctrl, focusNode, onSubmit) => TextFormField(
                controller: ctrl,
                focusNode: focusNode,
                decoration: const InputDecoration(labelText: 'Category *'),
                onChanged: (v) => _categoryCtrl.text = v,
                validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descCtrl,
              decoration: const InputDecoration(labelText: 'Description (optional)'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _amountCtrl,
              decoration: const InputDecoration(labelText: 'Amount *'),
              keyboardType: TextInputType.number,
              validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.calendar_today, color: AppTheme.primary),
              title: Text(DateFormat('dd MMM yyyy').format(_dateTime)),
              subtitle: const Text('Date'),
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _dateTime,
                  firstDate: DateTime(2000),
                  lastDate: DateTime.now(),
                );
                if (d != null) setState(() => _dateTime = d);
              },
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          child: Text(_isNew ? 'Add' : 'Save'),
        ),
      ],
    );
  }
}
