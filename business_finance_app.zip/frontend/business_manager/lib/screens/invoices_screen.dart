import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../utils/theme.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  List<dynamic> _invoices = [];
  bool _loading = true;
  String? _statusFilter;
  final _numFmt = NumberFormat('#,##0.00');
  final _dateFmt = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.getInvoices(status: _statusFilter);
      setState(() { _invoices = data; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _openCreateDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _CreateInvoiceDialog(onSaved: _load),
    );
  }

  Future<void> _confirmInvoice(String id) async {
    try {
      await ApiService.confirmInvoice(id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invoice confirmed — transactions created'),
            backgroundColor: AppTheme.success));
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _generatePdf(String id) async {
    try {
      await ApiService.generateInvoicePdf(id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PDF generated successfully'), backgroundColor: AppTheme.success));
      _load();
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'draft': return Colors.grey;
      case 'confirmed': return AppTheme.primary;
      case 'paid': return AppTheme.success;
      case 'unpaid': return AppTheme.danger;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoices'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(icon: const Icon(Icons.add), onPressed: _openCreateDialog),
        ],
      ),
      body: Column(
        children: [
          // Status filter
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                const Text('Filter:', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(width: 12),
                ...[null, 'draft', 'confirmed', 'paid', 'unpaid'].map((s) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(s == null ? 'All' : s[0].toUpperCase() + s.substring(1)),
                    selected: _statusFilter == s,
                    onSelected: (_) { setState(() => _statusFilter = s); _load(); },
                    selectedColor: AppTheme.primary.withOpacity(0.15),
                  ),
                )),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _invoices.isEmpty
                    ? const Center(child: Text('No invoices found.'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _invoices.length,
                        itemBuilder: (_, i) {
                          final inv = _invoices[i] as Map<String, dynamic>;
                          final status = inv['status'] as String;
                          final items = (inv['items'] as List?) ?? [];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            child: ExpansionTile(
                              leading: CircleAvatar(
                                backgroundColor: _statusColor(status).withOpacity(0.15),
                                child: Icon(Icons.receipt_long, color: _statusColor(status), size: 20),
                              ),
                              title: Row(
                                children: [
                                  Text('#${(inv['id'] as String).substring(0, 8).toUpperCase()}',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'monospace')),
                                  const SizedBox(width: 12),
                                  Text(inv['company_name'] ?? '',
                                    style: const TextStyle(fontWeight: FontWeight.w500)),
                                ],
                              ),
                              subtitle: Text(
                                'Issued: ${_dateFmt.format(DateTime.parse(inv['issue_date']))}  •  '
                                '${inv['due_date'] != null ? 'Due: ${_dateFmt.format(DateTime.parse(inv['due_date']))}' : 'No due date'}',
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(_numFmt.format(inv['total_amount']),
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: _statusColor(status).withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(status.toUpperCase(),
                                      style: TextStyle(
                                          color: _statusColor(status),
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                              children: [
                                // Line items
                                if (items.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                    child: Table(
                                      columnWidths: const {
                                        0: FlexColumnWidth(3),
                                        1: FlexColumnWidth(1),
                                        2: FlexColumnWidth(1),
                                        3: FlexColumnWidth(1),
                                      },
                                      children: [
                                        TableRow(
                                          decoration: BoxDecoration(color: AppTheme.background),
                                          children: ['Item', 'Qty', 'Unit Price', 'Total']
                                              .map((h) => Padding(
                                                padding: const EdgeInsets.all(6),
                                                child: Text(h, style: const TextStyle(
                                                    fontWeight: FontWeight.bold, fontSize: 12)),
                                              )).toList(),
                                        ),
                                        ...items.map((item) => TableRow(children: [
                                          Padding(padding: const EdgeInsets.all(6),
                                            child: Text(item['material_name'] ?? '')),
                                          Padding(padding: const EdgeInsets.all(6),
                                            child: Text(item['quantity'].toString())),
                                          Padding(padding: const EdgeInsets.all(6),
                                            child: Text(_numFmt.format(item['unit_price']))),
                                          Padding(padding: const EdgeInsets.all(6),
                                            child: Text(_numFmt.format(item['line_total']))),
                                        ])),
                                      ],
                                    ),
                                  ),
                                // Action buttons
                                Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Row(
                                    children: [
                                      if (status == 'draft') ...[
                                        ElevatedButton.icon(
                                          icon: const Icon(Icons.check_circle_outline, size: 16),
                                          label: const Text('Confirm'),
                                          onPressed: () => _confirmInvoice(inv['id']),
                                        ),
                                        const SizedBox(width: 8),
                                      ],
                                      OutlinedButton.icon(
                                        icon: const Icon(Icons.picture_as_pdf, size: 16),
                                        label: const Text('Generate PDF'),
                                        onPressed: () => _generatePdf(inv['id']),
                                      ),
                                      if (inv['pdf_path'] != null) ...[
                                        const SizedBox(width: 8),
                                        OutlinedButton.icon(
                                          icon: const Icon(Icons.download, size: 16),
                                          label: const Text('Download PDF'),
                                          onPressed: () {
                                            // Open download URL in browser
                                            final url = ApiService.invoicePdfDownloadUrl(inv['id']);
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              SnackBar(content: Text('Download URL: $url')));
                                          },
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

// ── Create Invoice Dialog ────────────────────────────────────────────────────
class _CreateInvoiceDialog extends StatefulWidget {
  final VoidCallback onSaved;
  const _CreateInvoiceDialog({required this.onSaved});

  @override
  State<_CreateInvoiceDialog> createState() => _CreateInvoiceDialogState();
}

class _CreateInvoiceDialogState extends State<_CreateInvoiceDialog> {
  List<dynamic> _companies = [];
  List<dynamic> _materials = [];
  Map<String, dynamic>? _selectedCompany;
  DateTime? _dueDate;
  final List<_LineItem> _items = [_LineItem()];
  bool _loading = true;
  bool _saving = false;
  final _numFmt = NumberFormat('#,##0.00');

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final companies = await ApiService.getCompanies();
      final materials = await ApiService.getMaterials();
      setState(() {
        _companies = companies;
        _materials = materials;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  double get _total => _items.fold(0, (sum, item) => sum + item.lineTotal);

  Future<void> _save() async {
    if (_selectedCompany == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a company')));
      return;
    }
    if (_items.any((i) => i.material == null)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select material for all items')));
      return;
    }

    setState(() => _saving = true);
    try {
      await ApiService.createInvoice({
        'company_id': _selectedCompany!['id'],
        'due_date': _dueDate?.toIso8601String().split('T').first,
        'items': _items.map((item) => {
          'material_id': item.material!['id'],
          'quantity': item.qty,
          'unit_price': item.unitPrice,
        }).toList(),
      });
      widget.onSaved();
      Navigator.pop(context);
    } on ApiException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Create Invoice'),
      content: _loading
          ? const SizedBox(height: 120, child: Center(child: CircularProgressIndicator()))
          : SizedBox(
              width: 600,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DropdownButtonFormField<Map<String, dynamic>>(
                      value: _selectedCompany,
                      decoration: const InputDecoration(labelText: 'Bill To (Company) *'),
                      items: _companies.map((c) => DropdownMenuItem(
                        value: c as Map<String, dynamic>,
                        child: Text(c['name']),
                      )).toList(),
                      onChanged: (v) => setState(() => _selectedCompany = v),
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.calendar_today, color: AppTheme.primary),
                      title: Text(_dueDate == null
                          ? 'No due date'
                          : DateFormat('dd MMM yyyy').format(_dueDate!)),
                      subtitle: const Text('Due Date (optional)'),
                      onTap: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now().add(const Duration(days: 30)),
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (d != null) setState(() => _dueDate = d);
                      },
                    ),
                    const Divider(),
                    const Text('Line Items', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    ..._items.asMap().entries.map((entry) {
                      final idx = entry.key;
                      final item = entry.value;
                      return _LineItemRow(
                        item: item,
                        materials: _materials,
                        onChanged: () => setState(() {}),
                        onRemove: _items.length > 1 ? () => setState(() => _items.removeAt(idx)) : null,
                        numFmt: _numFmt,
                      );
                    }),
                    TextButton.icon(
                      icon: const Icon(Icons.add),
                      label: const Text('Add Item'),
                      onPressed: () => setState(() => _items.add(_LineItem())),
                    ),
                    const Divider(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Text('Total: ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        Text(_numFmt.format(_total),
                          style: const TextStyle(fontWeight: FontWeight.bold,
                              fontSize: 18, color: AppTheme.primary)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: (_saving || _loading) ? null : _save,
          child: const Text('Create Invoice'),
        ),
      ],
    );
  }
}

class _LineItem {
  Map<String, dynamic>? material;
  double qty = 1;
  double unitPrice = 0;

  double get lineTotal => qty * unitPrice;
}

class _LineItemRow extends StatelessWidget {
  final _LineItem item;
  final List<dynamic> materials;
  final VoidCallback onChanged;
  final VoidCallback? onRemove;
  final NumberFormat numFmt;

  const _LineItemRow({
    required this.item, required this.materials,
    required this.onChanged, this.onRemove, required this.numFmt,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: DropdownButtonFormField<Map<String, dynamic>>(
              value: item.material,
              decoration: const InputDecoration(labelText: 'Material', isDense: true),
              items: materials.map((m) => DropdownMenuItem(
                value: m as Map<String, dynamic>,
                child: Text(m['name']),
              )).toList(),
              onChanged: (v) {
                item.material = v;
                item.unitPrice = double.tryParse(v?['unit_price'].toString() ?? '0') ?? 0;
                onChanged();
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              initialValue: item.qty.toString(),
              decoration: const InputDecoration(labelText: 'Qty', isDense: true),
              keyboardType: TextInputType.number,
              onChanged: (v) { item.qty = double.tryParse(v) ?? 1; onChanged(); },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              initialValue: item.unitPrice.toString(),
              decoration: const InputDecoration(labelText: 'Price', isDense: true),
              keyboardType: TextInputType.number,
              onChanged: (v) { item.unitPrice = double.tryParse(v) ?? 0; onChanged(); },
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 80,
            child: Text(numFmt.format(item.lineTotal),
              style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          IconButton(
            icon: const Icon(Icons.remove_circle_outline, color: AppTheme.danger),
            onPressed: onRemove,
          ),
        ],
      ),
    );
  }
}
