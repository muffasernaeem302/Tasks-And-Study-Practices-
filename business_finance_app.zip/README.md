# Business Finance Manager

A full-stack desktop application for managing business transactions, inventory, invoices, ledgers, and expenses.

**Stack:** Flutter (Desktop) + FastAPI (Python) + PostgreSQL

---

## Project Structure

```
business_finance_app/
├── backend/                    # FastAPI Python backend
│   ├── app/
│   │   ├── api/endpoints/      # Route handlers
│   │   │   ├── auth.py         # Login, register, change password
│   │   │   ├── companies.py    # Companies & sub-companies CRUD
│   │   │   ├── materials.py    # Materials & inventory CRUD
│   │   │   ├── transactions.py # Transactions + ledger
│   │   │   ├── payments.py     # Partial payments
│   │   │   ├── expenses.py     # Business expenses
│   │   │   ├── invoices.py     # Invoices + PDF generation
│   │   │   ├── dashboard.py    # Summary & notifications
│   │   │   └── backup.py       # CSV export + pg_dump
│   │   ├── core/
│   │   │   ├── config.py       # Settings (reads .env)
│   │   │   └── security.py     # JWT + bcrypt
│   │   ├── db/
│   │   │   └── database.py     # SQLAlchemy engine & session
│   │   ├── models/             # SQLAlchemy ORM models
│   │   ├── schemas/            # Pydantic request/response schemas
│   │   └── services/
│   │       └── pdf_service.py  # ReportLab invoice PDF generation
│   ├── alembic/                # Database migrations
│   ├── tests/
│   │   └── test_api.py         # Pytest test suite
│   ├── init.sql                # Direct SQL setup (alternative to Alembic)
│   ├── main.py                 # FastAPI application entry point
│   ├── requirements.txt        # Python dependencies
│   ├── Dockerfile
│   └── .env.example            # Copy to .env and fill in values
│
├── frontend/business_manager/  # Flutter desktop app
│   ├── lib/
│   │   ├── main.dart           # App entry point
│   │   ├── screens/
│   │   │   ├── login_screen.dart
│   │   │   ├── home_screen.dart         # Navigation rail shell
│   │   │   ├── dashboard_screen.dart    # Summary cards & alerts
│   │   │   ├── transaction_entry_screen.dart
│   │   │   ├── companies_screen.dart
│   │   │   ├── ledger_screen.dart       # Per-company ledger
│   │   │   ├── materials_screen.dart
│   │   │   ├── expenses_screen.dart
│   │   │   ├── invoices_screen.dart
│   │   │   └── settings_screen.dart
│   │   ├── services/
│   │   │   └── api_service.dart         # HTTP client for all API calls
│   │   └── utils/
│   │       └── theme.dart               # Colors, typography, theme
│   └── pubspec.yaml
│
├── docker-compose.yml          # Spin up DB + backend together
└── README.md
```

---

## Quick Start — Option A: Docker (Recommended)

### Prerequisites
- Docker Desktop installed

### Steps

```bash
# 1. Clone / navigate to project root
cd business_finance_app

# 2. Start database + backend
docker-compose up -d

# 3. API is now live at http://localhost:8000
#    Interactive docs: http://localhost:8000/docs

# 4. Default login: admin / admin123  (CHANGE THIS IMMEDIATELY)
```

---

## Quick Start — Option B: Manual Setup

### 1. Database

**Option 1 — Supabase (fastest):**
- Create a free project at https://supabase.com
- Copy the connection string from Settings → Database
- Run `init.sql` in the Supabase SQL editor

**Option 2 — Local PostgreSQL:**
```bash
psql -U postgres -c "CREATE DATABASE business_finance_db;"
psql -U postgres -d business_finance_db -f backend/init.sql
```

### 2. Backend

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env: set DATABASE_URL, SECRET_KEY, and company profile

# Run development server
uvicorn main:app --reload

# API docs: http://localhost:8000/docs
```

### 3. Flutter Frontend

```bash
# Install Flutter SDK from https://flutter.dev
flutter doctor                    # fix any issues it reports

cd frontend/business_manager

# Enable desktop target (run once per machine)
flutter config --enable-windows-desktop   # or macos / linux

# Get dependencies
flutter pub get

# Run on desktop
flutter run -d windows            # or macos / linux
```

---

## Environment Variables (.env)

| Variable | Description | Default |
|---|---|---|
| `DATABASE_URL` | PostgreSQL connection string | — |
| `SECRET_KEY` | JWT signing secret (keep secret!) | — |
| `ALGORITHM` | JWT algorithm | HS256 |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Token lifetime | 1440 (24h) |
| `INVOICE_PDF_DIR` | Where generated PDFs are stored | ./generated_invoices |
| `BACKUP_DIR` | Where database backups are stored | ./backups |
| `COMPANY_NAME` | Your company name (on invoices) | — |
| `COMPANY_ADDRESS` | Your company address | — |
| `COMPANY_PHONE` | Your company phone | — |
| `COMPANY_EMAIL` | Your company email | — |

---

## API Reference

All routes require `Authorization: Bearer <token>` except `/api/auth/login` and `/api/auth/register`.

Interactive docs available at `http://localhost:8000/docs` when running.

### Authentication
| Method | Path | Description |
|---|---|---|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login → returns JWT |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/auth/change-password` | Change password |

### Companies
| Method | Path | Description |
|---|---|---|
| GET | `/api/companies/` | List all companies |
| POST | `/api/companies/` | Create company |
| GET | `/api/companies/{id}` | Get company (with sub-companies & balance) |
| PUT | `/api/companies/{id}` | Update company |
| DELETE | `/api/companies/{id}` | Delete company |

### Materials
| Method | Path | Description |
|---|---|---|
| GET | `/api/materials/` | List all materials |
| POST | `/api/materials/` | Create material |
| GET | `/api/materials/{id}` | Get material |
| PUT | `/api/materials/{id}` | Update material |
| DELETE | `/api/materials/{id}` | Delete material |
| GET | `/api/materials/low-stock/alerts` | Materials below threshold |

### Transactions
| Method | Path | Description |
|---|---|---|
| GET | `/api/transactions/` | List transactions (filterable) |
| POST | `/api/transactions/` | Create transaction (auto-adjusts inventory) |
| GET | `/api/transactions/{id}` | Get transaction |
| PUT | `/api/transactions/{id}` | Update transaction |
| GET | `/api/transactions/ledger/{company_id}` | Chronological ledger with running balance |

### Payments
| Method | Path | Description |
|---|---|---|
| POST | `/api/payments/` | Add payment to transaction |
| GET | `/api/payments/transaction/{id}` | List payments for a transaction |

### Expenses
| Method | Path | Description |
|---|---|---|
| GET | `/api/expenses/` | List expenses (filter by year/month/category) |
| POST | `/api/expenses/` | Create expense |
| PUT | `/api/expenses/{id}` | Update expense |
| DELETE | `/api/expenses/{id}` | Delete expense |
| GET | `/api/expenses/summary?year=2025` | Monthly breakdown + yearly total |

### Invoices
| Method | Path | Description |
|---|---|---|
| GET | `/api/invoices/` | List invoices (filter by status) |
| POST | `/api/invoices/` | Create invoice (draft) |
| GET | `/api/invoices/{id}` | Get invoice |
| PUT | `/api/invoices/{id}` | Update invoice |
| DELETE | `/api/invoices/{id}` | Delete draft invoice |
| POST | `/api/invoices/{id}/confirm` | Confirm invoice → creates transactions |
| POST | `/api/invoices/{id}/generate-pdf` | Generate PDF |
| GET | `/api/invoices/{id}/download-pdf` | Download PDF |

### Dashboard
| Method | Path | Description |
|---|---|---|
| GET | `/api/dashboard/summary` | Total receivable, payable, alerts |
| GET | `/api/dashboard/notifications` | Low-stock + unpaid invoice alerts |

### Backup & Export
| Method | Path | Description |
|---|---|---|
| GET | `/api/backup/export/transactions` | CSV export |
| GET | `/api/backup/export/expenses` | CSV export |
| GET | `/api/backup/export/companies` | CSV export |
| GET | `/api/backup/export/materials` | CSV export |
| POST | `/api/backup/database` | pg_dump full backup |
| GET | `/api/backup/database/{filename}` | Download backup file |

---

## Running Tests

```bash
cd backend
pip install pytest pytest-asyncio httpx
pytest tests/ -v
```

---

## Build for Production (Flutter)

```bash
cd frontend/business_manager

# Windows
flutter build windows

# macOS
flutter build macos

# Linux
flutter build linux
```

The built executable will be in `build/windows/runner/Release/` (or macos/linux equivalent).

---

## Security Checklist Before Going Live

- [ ] Change `SECRET_KEY` in `.env` to a long random string
- [ ] Change the default `admin` password
- [ ] Restrict `CORS` origins in `main.py` to your actual domain
- [ ] Use HTTPS in production (nginx reverse proxy)
- [ ] Set `DEBUG=false` in `.env`
- [ ] Rotate JWT tokens regularly (reduce `ACCESS_TOKEN_EXPIRE_MINUTES`)
- [ ] Set up automated database backups

---

## Build Order (Phase Reference)

Follow Phases 1–6 from the blueprint:
1. **Phase 1** — Environment setup (done when you run the app)
2. **Phase 2** — Backend core CRUD (all endpoints in `app/api/endpoints/`)
3. **Phase 3** — Invoices, PDF, ledger, exports (all built)
4. **Phase 4** — Flutter screens (all 8 screens built)
5. **Phase 5** — Polish, test, security review
6. **Phase 6** — Enable Android build target in Flutter
